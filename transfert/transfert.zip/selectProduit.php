<?php
require('../database.php');

   echo " <select id='produit' name='produit' onchange='goProduit()'>
    ";


   if(isset($_POST["idNavire"])){

     $b=$_POST["idNavire"];
$b=$_POST["idNavire"];
$_SESSION['produit']=$b;
                   
//$bdd=new PDO('mysql:host=localhost;dbname=publicite;charset=utf8;', 'root', '');


         echo  "<option  selected>Selectionner produit</option>";

     
   
                $resP = $bdd->prepare("SELECT dis.*,mang.*, p.produit,p.qualite FROM dispatching as dis
                inner join produit_deb as p on dis.id_produit=p.id
                 inner join mangasin as mang on dis.id_mangasin=mang.id
                

            WHERE dis.id_navire=? " );
        $resP->bindParam(1,$b);
       
        
        $resP->execute();
        while($row2 = $resP->fetch(PDO::FETCH_ASSOC)){
            
            ?>

            
              <option   value=<?php echo $row2['id_dis']; ?> > <span class="produit"> <?php echo $row2['produit']; ?></span>  <span class="poids"><?php echo $row2['poids_kg']; ?> KGS</span> DESTINATION:<?php echo $row2['mangasin']; ?> </option>
               <?php  } ?>

             

            </select>
<?php 



}  
    ?>
             




