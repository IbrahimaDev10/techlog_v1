<?php 

require('../database.php');


if (isset($_POST['navire'])) {
    // code...
    if(!empty($_POST['navire']) and !empty($_POST['id_produit'])  and !empty($_POST['poids_sac']) and !empty($_POST['dates'])    and !empty($_POST['cale']) and !empty($_POST['heure']) and !empty($_POST['declaration']) and !empty($_POST['bl']) /* and !empty($_POST['camions']) and !empty($_POST['chauffeur'])  and !empty($_POST['permis']) and !empty($_POST['tel'])  and !empty($_POST['transport'])*/      and !empty($_POST['client'])    and !empty($_POST['sacf']) and !empty($_POST['sacm']) and !empty($_POST['poidsf'])  ){

        $nav=$_POST['navire'];
        $prod=$_POST['id_produit'];
        $poids=$_POST['poids_sac']; 
        $date=$_POST['dates'];
        $heure=$_POST['heure'];
        $declaration=$_POST['declaration'];
        $id_di=$_POST['id_dis'];
        
        $cale=$_POST['cale']; 
        //$chauffeur=$_POST['chauffeur'];
        $camions=$_POST['val_input3'];
        $chauffeur=$_POST['val_input3c'];
        //$cam=explode(",", $chauffeur);
       // $permis=$_POST['permis'];
       // $tel=$_POST['tel'];
       // $transport=$_POST['transport'];
        $essai=9;
        $essai2=1;
         
        $bl=$_POST['bl']; 
        $sacf=$_POST['sacf']; 
         $sacm=$_POST['sacm']; 
          $poidsf=$_POST['poidsf']; 
          $poidsm=$_POST['poidsm'];
        $poids_net=$_POST['poids_sac'];
        $client=$_POST['client'];
        $destination=$_POST['mangasin'];
         $autre_destination=$_POST['autre_destinataire'];

        $destinataire=$_POST['destinataire'];

        $poids_mouille=$sacm*$poids/1000;

try{


    $insertRecep1= $bdd->prepare("INSERT INTO transfert_avaries(date_tr_avaries,heure_tr,cale_tr_avaries,bl_tr,id_cam,id_chauffeur_tr,sac_flasque_tr_av,poids_flasque_tr_av,sac_mouille_tr_av,poids_mouille_tr_av,id_dis_bl_tr,id_declaration_tr,poids_sac_tr_av,id_produit,id_client,id_destination_tr,id_navire,autre_destination_tr,destinataire_tr) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"); 

    $insertRecep1->bindParam(1,$date); 
$insertRecep1->bindParam(2,$heure);

$insertRecep1->bindParam(3,$cale);
$insertRecep1->bindParam(4,$bl);

$insertRecep1->bindParam(5,$camions);
$insertRecep1->bindParam(6,$chauffeur);
$insertRecep1->bindParam(7,$sacf);
$insertRecep1->bindParam(8,$poidsf);
$insertRecep1->bindParam(9,$sacm);

$insertRecep1->bindParam(10,$poids_mouille);
$insertRecep1->bindParam(11,$id_di);
$insertRecep1->bindParam(12,$declaration);
$insertRecep1->bindParam(13,$poids_net);
$insertRecep1->bindParam(14,$prod);
$insertRecep1->bindParam(15,$client);
$insertRecep1->bindParam(16,$destination);
$insertRecep1->bindParam(17,$nav);
 $insertRecep1->bindParam(18,$autre_destination);
 $insertRecep1->bindParam(19,$destinataire);
 $insertRecep1->execute();
 echo   'Insertion reussi';

$select=$bdd->query("select id_tr_avaries from transfert_avaries order by id_tr_avaries desc");
$sel=$select->fetch();
if($sel){
    $insert=$bdd->prepare("INSERT INTO pre_reception_avaries(id_pre_tr_av) values(?)" );
    $insert->bindParam(1,$sel['id_tr_avaries']);
    $insert->execute();

}

}
catch(Exception $e){

    }

}
    else{
 echo '<center><div  class="err" id="erreur" ><button  type="button" class="btn-close"  id="close_erreur" onclick="fermer()" ></button><h3 id="perreur"> ERREUR</h3>
 <h5 id="perreur"> Veuillez si tous les les champs ont été bien saisi ou selectionner</h5></div></center>';
 
}



$afficheAvaries = $bdd->prepare("SELECT p.produit,p.qualite,nav.navire,nav.type,cli.client,mang.mangasin,trp.*,trs.*,ch.*,trav.*,cam.*, sum(trav.sac_flasque_tr_av),sum(trav.poids_flasque_tr_av),sum(trav.poids_mouille_tr_av),sum(trav.sac_mouille_tr_av)   FROM transfert_avaries as trav 
                
                inner join  produit_deb as p on trav.id_produit=p.id 

                inner join navire_deb as nav on trav.id_navire=nav.id 
                
                inner join client as cli on trav.id_client=cli.id
                inner join mangasin as mang on trav.id_destination_tr=mang.id
                left join camions as cam on trav.id_cam=cam.id_camions
                left join transporteur as trp on cam.id_trans=trp.id
                left join chauffeur as ch on trav.id_chauffeur_tr=ch.id_chauffeur 
                inner join transit as trs on trav.id_declaration_tr=trs.id_trans

                   WHERE trav.id_dis_bl_tr=? and trav.bl_tr!='ref' group by trav.date_tr_avaries, trav.id_tr_avaries with rollup ");
        
        
        $afficheAvaries->bindParam(1,$id_di);
        $afficheAvaries->execute();


$rob=$bdd->prepare("select dis.*, rm.*, sum(rm.sac),sum(rm.poids), n.type FROM dispatching as dis
         
          inner  join register_manifeste as rm on  dis.id_produit=rm.id_produit and dis.id_dis=rm.id_dis_bl
          and dis.id_mangasin=rm.id_destination

          and dis.poids_kg=rm.poids_sac and dis.id_navire=rm.id_navire
        inner join navire_deb as n on dis.id_navire=n.id
          
         where  dis.id_dis=?  ");
         $rob->bindParam(1,$id_di);
         $rob->execute();

         $rob_colone=$bdd->prepare("select n.type , dis.poids_kg, dis.* from dispatching as dis inner join navire_deb as n
         on n.id=dis.id_navire where dis.id_dis=?");
         $rob_colone->bindParam(1,$id_di);
         $rob_colone->execute();
         

         $rob_dec=$bdd->prepare("SELECT trans.poids_declarer, trans.numero_declaration, sum(rm.sac), sum(rm.poids) from transit as trans left join register_manifeste as rm on trans.id_trans=rm.id_declaration
            
          WHERE trans.id_bl=?  group by trans.numero_declaration");
                   $rob_dec->bindParam(1,$id_di);
         $rob_dec->execute();

          $rob_dec2=$bdd->prepare("SELECT trans.poids_declarer, trans.numero_declaration,  sum(tr.poids_flasque_tr_av),sum(tr.poids_mouille_tr_av)  from transit as trans  
           left join transfert_avaries as tr on trans.id_trans=tr.id_declaration_tr 
          WHERE trans.id_bl=?  group by trans.numero_declaration");
                   $rob_dec2->bindParam(1,$id_di);
         $rob_dec2->execute();


               $res3_avt = $bdd->prepare("SELECT  p.produit,p.qualite,nav.navire,cli.client,mang.mangasin, nav.id, nav.type, dis.*   FROM dispatching as dis 
                
                inner join  produit_deb as p on dis.id_produit=p.id 

                inner join navire_deb as nav on dis.id_navire=nav.id 
                
                inner join client as cli on dis.id_client=cli.id
                inner join mangasin as mang on dis.id_mangasin=mang.id
                

                   WHERE dis.id_dis=? ");
        
        $res3_avt ->bindParam(1,$c);
        $res3_avt ->execute();



 ?>


<div id="tr_avariess">
<div class="container-fluid" id="TableAvariesTrans" >

        <div class="col-md-12 col-lg-12">      
<button type="submit" class="btn1" data-bs-toggle="modal" data-bs-target="#enregistrement_transfert" >Insertion transfert avaries</button>
<br><br>


</span>
    </div>

 <div class="table-responsive" border=1>
<?php


 echo " <table class='table table-hover table-bordered table-striped' id='table' border='2' >";
    
?> 
 <thead >
    <td  colspan="15" class="titreTRANSAV"  >TRANSFERT DES AVARIES DE DEBARQUEMENT</td>   

    <?php while($row3=$res3_avt->fetch()) {?>
  
   <br>

    <tr id="entete_table_transfert_avaries" style="text-align: center; vertical-align: middle; " >
      <div style="display: flex; justify-content: center;"> 
       <td id="eliminer_border"  colspan="3"> 
 <span class="titre_entete" > NAVIRE:</span>        
    <span class="contenu_entete"><?php echo $row3['navire'];?></span>
    </td>
     <td id="eliminer_border" colspan="4"> 
 <span class="titre_entete" > CONNAISSEMENT:</span>        
    <span class="contenu_entete"><?php echo $row3['n_bl'];?></span>
    </td>
     <td id="eliminer_border" colspan="5"><span class="titre_entete" > PRODUIT:</span><span class="contenu_entete"> <?php echo $row3['produit'];?> <span class="contenu_entete" > <?php  echo $row3['qualite'];?></span> <?php if($row3['poids_kg']!=0){ echo $row3['poids_kg'];?>KGS <?php } ?></span> </td>
      <td id="eliminer_border" colspan="3">
      <span class="titre_entete" > POIDS:</span>        
        <span class="contenu_entete" ><?php  
        echo number_format($row3['poids_t'], 3,',',' ');
    ?></span></td>
  </tr>

<tr id="entete_table_transfert_avaries" style="text-align: center; vertical-align: middle; " >
      <td id="eliminer_border" colspan="6">
  <span class="titre_entete" > DESTINATION DOUANIERE:</span>
 <span class="contenu_entete" ><?php  
        echo $row3['des_douane'];
    ?></span></td>  

 
<td id="eliminer_border" colspan="5">
    <span class="titre_entete" > RECEPTIONNAIRE:</span>        
        <span class="contenu_entete" ><?php  
        echo $row3['client'];
    ?></span></td> 
    
   <td id="eliminer_border" colspan="4">
   <span class="titre_entete" > DESTINATION:</span>        
        <span class="contenu_entete" ><?php  
        echo $row3['mangasin'];
    ?></span> </td> 
  </div>
  </tr>
   <?php } $res3_avt->closeCursor();?>
      
    
    <tr id="entete_table_transfert_avaries"  >
      
      
      
       <td scope="col"  rowspan="3"  style="vertical-align: middle;">DATES</td>
              <td scope="col"  rowspan="3" style="vertical-align: middle;" >HEURE</td>
                     <td scope="col"  rowspan="3" style="vertical-align: middle;" >CALE</td>
                      <td scope="col"  rowspan="3" style="vertical-align: middle;" >BL</td>
               <td scope="col" rowspan="3" style="vertical-align: middle;" >CAMIONS</td> 
               <td scope="col"  rowspan="3"  style="vertical-align: middle;">CHAUFFEUR</td>
               <td scope="col"  rowspan="3" style="vertical-align: middle;" >TRANSPORTEUR</td>
               <td scope="col"  rowspan="3"style="vertical-align: middle;" >N°DEC / TRANSFERT</td>            
      <td scope="col" colspan="2" >FLASQUES</td>
      <td scope="col" colspan="2" >MOUILLES</td>
      <td scope="col" colspan="2" >TOTAL AVARIES</td>
      <td scope="col" rowspan="2"  >ACTIONS</td>
      
     
  </tr>
    <tr id="entete_table_transfert_avaries" >
      
      <td scope="col"   >SACS</td>
      <td scope="col"  >POIDS</td>
      <td scope="col" >SACS</td>
      <td scope="col"  >POIDS</td>
      <td scope="col" >SACS</td>
      <td scope="col" >POIDS</td>
      </tr>
      

     
     
    


      
     </thead>


<tbody>
 <?php while($aff=$afficheAvaries->fetch()){ 
   $date=explode('-', $aff['date_tr_avaries']);
   $heure=explode(':', $aff['heure_tr']);
   $TotalSacAV=$aff['sum(trav.sac_flasque_tr_av)']+$aff['sum(trav.sac_mouille_tr_av)'];
   $TotalPoidsAV=$aff['sum(trav.poids_flasque_tr_av)']+$aff['sum(trav.poids_mouille_tr_av)'];
  
   //$diff=$aff['poids_declarer']-$aff['sum(manif.poids)'];
     
    ?>
    <tr style="text-align: center; font-weight: bold; " >
      <?php if(empty($aff['id_tr_avaries']) and !empty($aff['date_tr_avaries'])) {?>
      <td colspan="8" class="colaffnull" style="background:rgb(82,82,226); font-weight: bold; color:white;" >TOTAL <?php echo $date[2].'-'.$date[1].'-'.$date[0] ?></td>
   

    <td class="colaffnull" style="background:rgb(82,82,226); color: white;"><?php echo number_format($aff['sum(trav.sac_flasque_tr_av)'], 0,',',' ') ?></td>
    <td class="colaffnull" style="background:rgb(82,82,226); color: white;"><?php echo number_format($aff['sum(trav.poids_flasque_tr_av)'], 3,',',' '); ?></td>
    <td class="colaffnull" style="background:rgb(82,82,226); color: white;"><?php echo number_format($aff['sum(trav.sac_mouille_tr_av)'], 0,',',' ') ?></td>
     <td class="colaffnull" style="background:rgb(82,82,226); color: white;"><?php echo number_format($aff['sum(trav.poids_mouille_tr_av)'], 3,',',' '); ?></td>
         <td class="colaffnull" style="background:rgb(82,82,226); color: white;"><?php echo number_format($TotalSacAV, 0,',',' ') ?></td>
    <td class="colaffnull" style="background:rgb(82,82,226); color: white;"><?php echo number_format($TotalPoidsAV, 3,',',' ') ?></td>
             <td class="colaffnull" style="background:rgb(82,82,226); color: white;"></td>

    
    <?php if($aff['autre_destination_tr']!="AUCUNE"){ ?>
      <td class="colaffnull" style="background:rgb(82,82,226);"></td>
    <td class="colaffnull" style="background:rgb(82,82,226);"></td>
<?php } ?>


   
   <?php }



   else if(!empty($aff['id_tr_avaries']) and !empty($aff['date_tr_avaries'])) {?>

 <tr id="data_table_transfert_avaries">
    <td  id="<?php echo $aff['id_tr_avaries'].'date_av' ?>" ><?php echo  $date[2].'-'.$date[1].'-'.$date[0] ?></td>
    <td  id="<?php echo $aff['id_tr_avaries'].'heure_av' ?>" ><?php echo $heure[0].':'.$heure[1] ?></td>
    <td  id="<?php echo $aff['id_tr_avaries'].'cale_av' ?>" ><?php echo $aff['cale_tr_avaries'] ?></td>
    <td  id="<?php echo $aff['id_tr_avaries'].'bl_av' ?>" ><?php echo $aff['bl_tr'] ?></td>
    <td  id="<?php echo $aff['id_tr_avaries'].'camion_av' ?>" ><?php echo $aff['num_camions'] ?></td>
    <span style="display: none;" class="colaffiche" id="<?php echo $aff['id_tr_avaries'].'id_camion_av' ?>" ><?php echo $aff['id_cam'] ?></span>
    <td class="colaffiche" id="<?php echo $aff['id_tr_avaries'].'chauffeur_av' ?>" ><?php echo $aff['nom_chauffeur'] ?></td>
     <span style="display: none;" class="colaffiche" id="<?php echo $aff['id_tr_avaries'].'id_chauffeur_av' ?>" ><?php echo $aff['id_chauffeur_tr'] ?></span>
    
    <span id="<?php echo $aff['id_tr_avaries'].'disbl' ?>" style="display: none" class="colaffiche"><?php echo $aff['id_dis_bl_tr'] ?></span>
     <span id="<?php echo $aff['id_tr_avaries'].'dis_bl_av' ?>" style="display: none" class="colaffiche"><?php echo $aff['id_dis_bl_tr'] ?></span>
      <span id="<?php echo $aff['id_tr_avaries'].'poids_sac_av' ?>" style="display: none" class="colaffiche"><?php echo $aff['poids_sac_tr_av'] ?></span>
    <center>
    <td >
      <?php  echo $aff['nom']; ?></td>
    </center>
    <td  id="<?php echo $aff['id_tr_avaries'].'declaration_av' ?>" ><?php echo $aff['numero_declaration'] ?></td>
    <span id="<?php echo $aff['id_tr_avaries'].'id_declaration_av' ?>" style="display: none" class="colaffiche"><?php echo $aff['id_declaration_tr']; ?></span>


    <td id="<?php echo $aff['id_tr_avaries'].'sacf_av' ?>" class="colaffiche"><?php echo number_format($aff['sac_flasque_tr_av'], 0,',',' '); ?></td>
    <td  id="<?php echo $aff['id_tr_avaries'].'poidsf_av' ?>" ><?php echo $aff['poids_flasque_tr_av'] ?></td>
  <td  id="<?php echo $aff['id_tr_avaries'].'sacm_av' ?>" ><?php echo number_format($aff['sac_mouille_tr_av'], 0,',',' '); ?></td>
    <td class="colaffiche" id="<?php echo $aff['id_tr_avaries'].'poidsm_av' ?>" ><?php echo $aff['poids_mouille_tr_av'] ?></td>
    <td  style=""><?php echo number_format($TotalSacAV, 0,',',' ') ?></td>
    <td  style=""><?php echo number_format($TotalPoidsAV, 3,',',' ') ?></td>
    <td  style="vertical-align: middle; " >
    <div style="display: flex; justify-content: center;">
  <a class="fabtn"  data-role='update_register_avaries'   data-id="<?php echo $aff['id_tr_avaries'];  ?>"    ><i class="fa fa-edit " ></i></a>
     <a id="<?php echo $aff['id_tr_avaries'] ?>" type="submit"  class="fabtn1 "  onclick="deleteAvaries(<?php echo $aff['id_tr_avaries'] ?>)"  > <i class="fa fa-trash  " ></i> </a>
  </div>
</td>
     
     <?php if($aff['autre_destination_tr']!="AUCUNE"){ ?>
      <td ><?php echo $aff['autre_destination_tr'] ?></td>
    <td ><?php echo $aff['destinataire_tr'] ?></td>
<?php } ?>
  
</tr>


  
  <?php } ?>

  <?php   if(empty($aff['id_tr_avaries']) and empty($aff['date_tr_avaries'])) { /*
     $affT=$afficheT->fetch();
    $rob_sacT=$affT['nombre_sac']-$aff['sum(manif.sac)'];
     $rob_poidsT=$affT['poids_t']-$aff['sum(manif.poids)'];*/ 
     $TotalSacAV2=$aff['sum(trav.sac_flasque_tr_av)']+$aff['sum(trav.sac_mouille_tr_av)'];
   $TotalPoidsAV2=$aff['sum(trav.poids_flasque_tr_av)']+$aff['sum(trav.poids_mouille_tr_av)'];?>
<tr style="font-weight: bold;">
  <td colspan="8" class="" style="background: black; color: white; font-weight: bold; text-align: center;" > TOTAL </td>
  <td  class="" style="background: black; color: white; font-weight: bold; text-align: center;" > <?php echo number_format($aff['sum(trav.sac_flasque_tr_av)'], 0,',',' '); ?> </td>
   <td  class="" style="background: black; color: white; font-weight: bold; text-align: center;" > <?php echo number_format($aff['sum(trav.poids_flasque_tr_av)'], 3,',',' '); ?> </td>
    <td  class="" style="background: black; color: white; font-weight: bold; text-align: center;" > <?php echo number_format($aff['sum(trav.sac_mouille_tr_av)'], 0,',',' '); ?> </td>
     <td  class="" style="background: black; color: white; font-weight: bold; text-align: center;" > <?php echo number_format($aff['sum(trav.poids_mouille_tr_av)'], 3,',',' '); ?> </td>
     <td  class="" style="background: black; color: white; font-weight: bold; text-align: center;" > <?php echo number_format($TotalSacAV2, 0,',',' '); ?> </td>
     <td  class="" style="background: black; color: white; font-weight: bold; text-align: center;" > <?php echo number_format($TotalPoidsAV2, 3,',',' '); ?> </td>
     <td  class="" style="background: black; color: white; font-weight: bold; text-align: center;" >  </td>
  </tr>
  
 

  <?php  }  ?>
<?php  }  ?>



</tbody>
             

  
</table> 
</div>  
</div>
</div>



<?php } ?>


