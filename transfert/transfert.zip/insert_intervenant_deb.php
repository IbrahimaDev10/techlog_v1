<?php 
require("../database.php");
if(isset($_POST['id_navire'])){
  $id_navire=$_POST['id_navire'];
  $id_client=$_POST['id_client'];
  $inter=$_POST['intervenant'];

  $insert=$bdd->prepare("INSERT INTO intervenant_produit_deb(id_client_inter_prod,id_navire_inter_prod,id_inter) values(?,?,?) ");
  $insert->bindParam(1,$id_client);
  $insert->bindParam(2,$id_navire);
  $insert->bindParam(3,$id_navire);
  $insert->execute();

 $intervenant=$bdd->prepare("SELECT inter.*,intprod.* from intervenant_deb as inter inner join intervenant_produit_deb as intprod on inter.id_intervenant=intprod.id_inter_prod where intprod.id_client_inter_prod=? and intprod.id_navire_inter_prod=?  ");
             $intervenant->bindParam(1,$id_client);
             $intervenant->bindParam(2,$id_navire);
             $intervenant->execute();

 ?>

 <div id="afficher_intervenant">
          <div class="row">
            <div class="col-md-3 col-lg-2">
            <p style="color: black !important;">STEVEDORE</p><br><br><br>
            </div>
           <?php while ($inter=$intervenant->fetch()) { ?>
            <div class="col-md-6 col-lg-2">
            <p style="color: black !important;"><?php echo $inter['nom_intervenant']; ?></p>
            </div>
          <?php } ?>
          <div class="col-md-3 col-lg-2">
            <p style="color: black !important;">CHEF OFFICIER OF MASTER</p><br><br><br>
            </div>
          </div>
           </div>
         <?php } ?>