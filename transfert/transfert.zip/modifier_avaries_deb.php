<?php 
require("../database.php");
if(isset($_POST['id'])){

	 $date=$_POST['date'];
	 $d=explode('-', $date);
	 $insertdate=$d[2].'-'.$d[1].'-'.$d[0];
	 $sacf=$_POST['sacf'];
	 $sacm=$_POST['sacm'];
	 $id_navire=$_POST['id_navire'];
    $id_dis=$_POST['id_dis'];

	$id=$_POST['id'];
	$update=$bdd->prepare("UPDATE avaries set date_avaries=?, sac_flasque=?, sac_mouille=?  where id_avaries=?");
	$update->bindParam(1,$insertdate);
	$update->bindParam(2,$sacf);
	$update->bindParam(3,$sacm);
	$update->bindParam(4,$id);

	$update->execute();

  $avaries_deb=$bdd->prepare("SELECT p.produit,p.qualite, av.*, sum(av.sac_flasque),sum(av.sac_mouille) FROM avaries as av inner join produit_deb as p on av.id_produit=p.id WHERE av.id_dis_av=? and av.ref=1  GROUP BY av.date_avaries, av.id_avaries WITH ROLLUP");
 $avaries_deb->bindParam(1,$id_dis);
 $avaries_deb->execute();



         $rob_avr=$bdd->prepare("select dis.*,  rm.*, sum(rm.sac),sum(rm.poids), n.type FROM dispatching as dis
         
          inner  join register_manifeste as rm on  dis.id_produit=rm.id_produit and dis.id_dis=rm.id_dis_bl
          and dis.id_mangasin=rm.id_destination

          and dis.poids_kg=rm.poids_sac and dis.id_navire=rm.id_navire
        inner join navire_deb as n on dis.id_navire=n.id
          
         where  dis.id_dis=?  ");
         $rob_avr->bindParam(1,$id_dis);
         $rob_avr->execute();

         $rob_colone_avr=$bdd->prepare("select n.type , dis.poids_kg, dis.* from dispatching as dis inner join navire_deb as n
         on n.id=dis.id_navire where dis.id_dis=?");
         $rob_colone_avr->bindParam(1,$id_dis);
         $rob_colone_avr->execute();
         

         $rob_dec_avr=$bdd->prepare("SELECT trans.poids_declarer, trans.numero_declaration, sum(rm.sac), sum(rm.poids) from transit as trans left join register_manifeste as rm on trans.id_trans=rm.id_declaration
            
          WHERE trans.id_bl=?  group by trans.numero_declaration");
                   $rob_dec_avr->bindParam(1,$id_dis);
         $rob_dec_avr->execute();

          $rob_dec2_avr=$bdd->prepare("SELECT trans.poids_declarer, trans.numero_declaration,  sum(tr.poids_flasque_tr_av),sum(tr.poids_mouille_tr_av)  from transit as trans  
           left join transfert_avaries as tr on trans.id_trans=tr.id_declaration_tr 
          WHERE trans.id_bl=?  group by trans.numero_declaration");
                   $rob_dec2_avr->bindParam(1,$id_dis);
         $rob_dec2_avr->execute();

               $res3_avr = $bdd->prepare("SELECT  p.produit,p.qualite,nav.navire,cli.client,mang.mangasin, nav.id, nav.type, dis.*   FROM dispatching as dis 
                
                inner join  produit_deb as p on dis.id_produit=p.id 

                inner join navire_deb as nav on dis.id_navire=nav.id 
                
                inner join client as cli on dis.id_client=cli.id
                inner join mangasin as mang on dis.id_mangasin=mang.id
                

                   WHERE dis.id_dis=? ");
        
        $res3_avr ->bindParam(1,$id_dis);
        $res3_avr ->execute();
	?>

<div class="container-fluid" id="avaries_debarquement"  >

 <div class="entete_image" style="background-image: url('../images/bg_page.jpg'); background-repeat: no-repeat; background-size: 100%; background-color: blue;  ">
        <center> 
              
        <div   class="table-responsive" border=1>
          
  
 <table  class='table table-hover table-bordered table-striped'  border='2' style="width: 50%; " id='tabledec1'>
         
            <tr id="entete_table_declaration"  >
              <td  scope="col" style="color: white;">N° DECLARATION</td>
              <td  scope="col" style="color: white;">RESTANT SUR DECLARATION</td>
            </tr>
          
     
       <?php 
while($row=$rob_dec_avr->fetch()){
  $row2=$rob_dec2_avr->fetch();

$rob_poids=$row['poids_declarer']-$row['sum(rm.poids)']-$row2['sum(tr.poids_flasque_tr_av)']-$row2['sum(tr.poids_mouille_tr_av)'];
   ?>
   <tr id="data_table_declaration">
     
 
  <td>       
 <span class="th4" ><?php  
        echo  $row['numero_declaration']
    ?></span></td>
  <td>
            
 <span class="th4" ><?php  
        echo  number_format($rob_poids, 3,',',' ');
    ?></span>
  </td>
    </tr>
    
  <?php  } $rob_dec_avr->closeCursor(); ?>
   </table>
      </div>
       </center>
      <br> 
  
        <div  class="table-responsive" border=1 >
          <center>
 <table  class='table table-hover table-bordered table-striped'  border='2' style="width: 50%; " id='tabledec2' >

   
         
            <tr id="entete_table_declaration2" >
              <td colspan="2" scope="col" style="color: white;  ">TOTAL DEB</td>
              <td  colspan="2" style="color: white;">ROB</td>
            </tr>
            <tr id="entete_table_declaration2"> 
            <?php while  ($rcolone=$rob_colone_avr->fetch()){ 
             if($rcolone['type']=="SACHERIE"){ ?> 
            <td style="color: white;"> SACS </td> 
            <td style="color: white;">  POIDS</td>
          <?php }   
                     if($rcolone['type']=="VRAQUIER" and $rcolone['poids_kg']!=0 ){ ?> 
            <td style="color: white;"> SACS </td> 
            <td style="color: white;">  POIDS</td>
          <?php } 
                               if($rcolone['type']=="VRAQUIER" and $rcolone['poids_kg']==0 ){ ?> 
            
            <td colspan="2" style="color: white;">  POIDS</td>
          <?php } 
            

            if($rcolone['type']=="SACHERIE"){ ?>
             <td style="color: white;" id="entete_table_declaration2"> SACS </td> 
            <td style="color: white;" id="entete_table_declaration2">  POIDS</td>
          <?php } ?>
          <?php if($rcolone['type']=="VRAQUIER"){ ?>
             
            <td colspan="2" style="color: white;">  POIDS</td>
          <?php } ?>
        <?php } $rob_colone_avr->closeCursor(); ?>
            </tr>
 <?php 
while($row=$rob_avr->fetch()){
$rob_sac=$row['nombre_sac']-$row['sum(rm.sac)'];
$rob_poids=$row['poids_t']-$row['sum(rm.poids)'];
   ?>
   
   <tr id="data_table_declaration2"> <?php  if($row['type']=='SACHERIE'){ ?>
    <td>  
 <span class="th4" >
          <?php   echo number_format($row['sum(rm.sac)'], 0,',',' '); ?></span></td>
        <td>     
 <span class="th4" ><?php  
        echo $row['sum(rm.poids)'];
    ?></span></td>
  <?php } ?>
       <?php    if($row['type']=='VRAQUIER' and $row['poids_kg']!=0){ ?>
         <td>  <span class="th4" >
        <?php  
        echo number_format($row['sum(rm.sac)'], 0,',',' '); ?>
          

         </span></td>
        <td>     
 <span class="th4" ><?php  
        echo $row['sum(rm.poids)'];
    ?></span></td>
      
   <?php } 
     ?>

      <?php    if($row['type']=='VRAQUIER' and $row['poids_kg']==0){ ?>
        <td colspan="2"> 
                 
 <span class="th4" ><?php  
        echo $row['sum(rm.poids)'];
    ?></span></td>
      
   <?php } 
     ?>
 
         
 <?php   if($row['type']=='SACHERIE'){?>
 <td> <span class="th4" ><?php   
        echo  number_format($rob_sac, 0,',',' ');  ?>
  </span></td>
          
 <td> <span class="th4" ><?php  
        echo  number_format($rob_poids, 3,',',' ');
    ?></span></td>
  <?php } ?>

  <?php   if($row['type']=='VRAQUIER'){?>
 <
          
 <td colspan="2"> <span class="th4" ><?php  
        echo  number_format($rob_poids, 3,',',' ');
    ?></span></td>
  <?php } ?>
   </tr>

  <?php } $rob_avr->closeCursor(); ?>

          </table>
          </center>
        </div>

  
  </div>
<br>



  <div class="col-md-12 col-lg-12">      
<button style="background: orange;" type="submit" class="btn1" data-bs-toggle="modal" data-bs-target="#Les_avaries2" >Insertion </button>

</div>
<br>  

          <div class="table-responsive" border=1>
  
 <table class='table table-hover table-bordered table-striped table-responsive' id='table_register' border='2' >

 <thead style="background-color: rgba(50, 159, 218, 0.9);">
   <td  colspan="6" class="titreSAIN" style="background: orange;"  ><i class="fas fa-bell" style="float: left;"> </i> AVARIES DE DEBARQUEMENT</td>
     <?php while($row3=$res3_avr->fetch()) {?>
  
   <br>

    <tr style="text-align: center; vertical-align: middle; background: rgb(91,72,0);  " >
      <div style="display: flex; justify-content: center;"> 
       <td id="eliminer_border"  colspan="1"> 
 <span class="titre_entete" > NAVIRE:</span>        
    <span class="contenu_entete_avd"><?php echo $row3['navire'];?></span>
    </td>
     <td id="eliminer_border" colspan="2"> 
 <span class="titre_entete" > CONNAISSEMENT:</span>        
    <span class="contenu_entete_avd"><?php echo $row3['n_bl'];?></span>
    </td>
     <td id="eliminer_border" colspan="2"><span class="titre_entete" > PRODUIT:</span><span class="contenu_entete_avd"> <?php echo $row3['produit'];?> <span class="contenu_entete_avd" > <?php  echo $row3['qualite'];?></span> <?php if($row3['poids_kg']!=0){ echo $row3['poids_kg'];?>KGS <?php } ?></span> </td>
      <td id="eliminer_border" colspan="1">
      <span class="titre_entete" > POIDS:</span>        
        <span class="contenu_entete_avd" ><?php  
        echo number_format($row3['poids_t'], 3,',',' ');
    ?></span></td>
  </tr>


<tr style="text-align: center; vertical-align: middle; background: rgb(91,72,0); " >
      <td id="eliminer_border" colspan="2">
  <span class="titre_entete" > DESTINATION DOUANIERE:</span>
 <span class="contenu_entete_avd" ><?php  
        echo $row3['des_douane'];
    ?></span></td>  

 
<td id="eliminer_border" colspan="2">
    <span class="titre_entete" > RECEPTIONNAIRE:</span>        
        <span class="contenu_entete_avd" ><?php  
        echo $row3['client'];
    ?></span></td> 
    
   <td id="eliminer_border" colspan="2">
   <span class="titre_entete" > DESTINATION:</span>        
        <span class="contenu_entete_avd" ><?php  
        echo $row3['mangasin'];
    ?></span> </td> 
  </div>
  </tr>
 
  


   <?php } $res3_avr->closeCursor();?>
  
       
    
    <tr  style="background: linear-gradient(to bottom, #FFFFFF, orange); text-align: center; color: white; font-weight: bold; font-size: 12px;"  >
      <td class="mytd" scope="col" rowspan="2"  >DATES</td>
      <td class="mytd" scope="col" rowspan="2"  >PRODUIT</td>
      <td class="mytd" scope="col" rowspan="2"  >CALE</td>
      <td class="mytd" scope="col" rowspan="2" >SAC FLASQUE</td>
      <td class="mytd" scope="col" rowspan="2" > SAC MOUILLE</td>
      <td class="mytd" scope="col" rowspan="2" >ACTION</td>
    </tr>
    </thead>
    <tbody>
     <?php while($avrs=$avaries_deb->fetch()){

      if(!empty($avrs['date_avaries']) and !empty($avrs['id_avaries'])){
              $dates=explode('-', $avrs['date_avaries']);
             $dt=$dates[2].'-'.$dates[1].'-'.$dates[0];
        ?>
          <tr style="text-align: center; vertical-align: middle; background: white;">
<td id="<?php echo $avrs['id_avaries'].'date_avaries_deb' ?>"><?php echo $dt; ?></td>
          <td><?php echo $avrs['produit'] ?> <?php echo $avrs['qualite'] ?> <?php echo $avrs['poids_sac_avaries'].' KGS'; ?></td>
          <td><?php echo $avrs['cale_avaries']; ?></td>
          <td id="<?php echo $avrs['id_avaries'].'flasque_avaries_deb' ?>"><?php echo $avrs['sac_flasque']; ?></td>
          <td id="<?php echo $avrs['id_avaries'].'mouille_avaries_deb' ?>" ><?php echo $avrs['sac_mouille']; ?></td>
          <span style="display: none;" id="<?php echo $avrs['id_avaries'].'id_navire_avaries_deb' ?>" ><?php echo $avrs['id_navire']; ?></span>
           <span style="display: none;" id="<?php echo $avrs['id_avaries'].'id_dis_avaries_deb' ?>" ><?php echo $avrs['id_dis_av']; ?></span>
          <td> 

          <div style="display: flex; justify-content: center;">
           <a  class="fabtn" type=""   data-role='update_avaries_deb'  data-id="<?php echo $avrs['id_avaries']  ?>" > <i class="fa fa-edit " style="color: orange;" ></i></a>
           <a class="fabtn" type=""   onclick="delete_avaries_deb(<?php echo $avrs['id_avaries'] ?>)"   > <i class="fa fa-trash " style="color: orange;" ></i></a>
          </div>
         </td>
          

        </tr>
      <?php } 

      if(!empty($avrs['date_avaries']) and empty($avrs['id_avaries'])){
              $date=explode('-', $avrs['date_avaries']);
             $dt=$date[2].'-'.$date[1].'-'.$date[0];
        ?>
          <tr style="text-align: center; vertical-align: middle; background: rgb(91,72,0); color: white;">
<td style="color: white;" colspan="3"> TOTAL <?php echo $dt; ?></td>
         
          <td style="color: white;" ><?php echo $avrs['sum(av.sac_flasque)']; ?></td>
          <td style="color: white;"  ><?php echo $avrs['sum(av.sac_mouille)']; ?></td>
          <td style="color: white;"  ></td>
         
          

        </tr> 
      <?php } } ?>


    
    </tbody>
  </table>
</div>
</div>




<?php } ?>




