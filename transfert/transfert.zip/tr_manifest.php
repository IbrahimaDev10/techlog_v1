<?php
require('tr_action.php');
header("Cache-Control: no-cache, must-revalidate");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); 





$menu=$bdd->prepare('select * from navire_deb where id=?');
$menu->bindParam(1,$_SESSION['produit']);
$menu->execute();
$navbl=$bdd->query("select * from navire_deb order by id desc");
$navire=$bdd->query("select * from navire_deb order by id desc");

$navire2=$bdd->query("select * from navire_deb order by id desc");
if(isset($_POST['SIT'])){

    header('location:tr.situations.php');
    


}
$verific=$bdd->query("SELECT count(rm.bl), rm.bl, nav.id,nav.navire from register_manifeste as rm
      inner join navire_deb as nav on nav.id=rm.id_navire and rm.bl!='ref' group by rm.bl

      ");

?>	



<!DOCTYPE html>
<html lang="fr">
  <head>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    


	<title>Debarquement</title>

	<!-- Bootstrap CSS-->
    <?php include('tr_link.php'); ?>
</head>
<body >
<style type="text/css">
	
.lienforme{
color:white; font-size: 20px; border: solid; background-color: black; margin-bottom: 50px;

}

 *{
  font-family: Times New Roman;
 } 

   .fabtn{
  border: none;
  
  color:rgb(0,141,202);

 }
  .fabtn1{
  border: none;
  
  color:rgb(0,141,202);

 }
 .btn1{
  background: linear-gradient(to bottom, blue, #1B2B65); background: linear-gradient(to left, blue, #1B2B65); background: linear-gradient(to top, blue, #1B2B65);
 }
  .modal-header{
      
     /* background-image: url("images/simar2.jpg");
      background-repeat: no-repeat;
      background-size: 100%;
      background: #1B2B65;*/
       background: linear-gradient(to bottom, blue, #1B2B65);
       background: linear-gradient(to top, blue, #1B2B65);
       background: linear-gradient(to left, blue, #1B2B65);
      
      border-bottom-left-radius: 35%;
      border-bottom-right-radius: 35%;
      border: solid;
      border-color: rgb(145,145,255);
      border-width: 8px;
    }
    
  .modal-header{
      
     /* background-image: url("images/simar2.jpg");
      background-repeat: no-repeat;
      background-size: 100%;
      background: #1B2B65;*/
       background: linear-gradient(to bottom, blue, #1B2B65);
       background: linear-gradient(to top, blue, #1B2B65);
       background: linear-gradient(to left, blue, #1B2B65);
      
      border-bottom-left-radius: 35%;
      border-bottom-right-radius: 35%;
      border: solid;
      border-color: rgb(145,145,255);
      border-width: 8px;
    }
    
 .logoo{
      border-radius: 50px;
       height: 200px;
        width: 200px;
        margin-left: 40%;
        z-index: 2;
        text-align: center;

    }

    #perreur{
        color:red;
        font-weight: bold;
    }
    .err{
        width: 500px;
        height: 300px;
        background: white;
        vertical-align: middle;
    }
    #close_erreur{
        font-size: 30px;
    }

    #perreur2{
        color:red;
        font-weight: bold;
    }
    .err2{
        width: 500px;
        height: 300px;
        background: white;
        vertical-align: middle;
    }
    #close_erreur2{
        font-size: 30px;
    }
   
.mytd{
      font-size:14px;
    }

    .hem{

      color:white !important;
      background: rgb(0,44,62) !important;
      font-size: 30px !important;
      }
      @media (max-width: 800px) {
  .hem {
    font-size: 14px !important;
  }

</style>
<style type="text/css">
  #entete_table_sain{
background: linear-gradient(to bottom, #FFFFFF, rgb(0,141,202));
 text-align: center;
  color: white;
   font-weight: bold; 
   font-size: 12px;

}
#data_table_sain{

 text-align: center;
 vertical-align: middle;
   
   font-size: 12px;

}
#entete_table_transfert_avaries{
background: #1B2B65 ;
 text-align: center;
  color: white;
   font-weight: bold; 
   font-size: 12px;

}
#data_table_transfert_avaries{

 text-align: center;
 vertical-align: middle;
   
   font-size: 12px;

}
.titreSAIN{
  font-weight: bold;
   width: 100%;
   background: blue;
   text-align: center;
   font-size: 18px;
   border: solid;
  border-top-right-radius: 45%;
  border-bottom-right-radius: 45%;
   color: white !important;
}
.titreTRANSAV{
  font-weight: bold;
   width: 100%;
   background: blue !important;
   text-align: center;
   font-size: 18px;
   border: solid;
  border-top-right-radius: 45%;
  border-bottom-right-radius: 45%;
   color: white !important;
}
#btnSain{
  background:  rgba(50, 159, 218, 0.9) !important;
   width: 30%;
   font-weight: bolder;
}
 #btnAvariesRep{
  background: orange !important;
  
}

#btnAvariesDeb{
  background:  #1B2B65 !important;
  
}

    .ligne{
      font-size: 12px;
    }
    @media (max-width: 900px) {
  .ligne {
    font-size: 20px !important;
  }
}
  @media (max-width: 900px) {
  .colaffiche {
    font-size: 29px !important;
  }
  .ligne{
      font-size: 20px;
    }
} 

</style>



  
  <!--Topbar -->
  <div class="topbar transition">
	<div class="bars">
		<button type="button" class="btn transition" id="sidebar-toggle">
			<i class="fa fa-bars"></i>
		</button>
	</div>
		<div class="menu">
			<ul>
				<li class="nav-item dropdown dropdown-list-toggle">
					<a class="nav-link" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
					   <i class="fa fa-bell size-icon-1"></i><span class="badge bg-danger notif">4</span>
					</a> 				 
					<div class="dropdown-menu dropdown-list">
						<div class="dropdown-header">Notifications</div>
						<div class="dropdown-list-content dropdown-list-icons">
							<div class="custome-list-notif"> 
							<a href="#" class="dropdown-item dropdown-item-unread">
								<div class="dropdown-item-icon bg-primary text-white">
								  <i class="fas fa-code"></i>
								</div>
								<div class="dropdown-item-desc">
									The Atrana template has the latest update!
								  <div class="time text-primary">3 Min Ago</div>
								</div>
							  </a>

							  <a href="#" class="dropdown-item">
								<div class="dropdown-item-icon bg-info text-white">
								  <i class="far fa-user"></i>
								</div>
								<div class="dropdown-item-desc">
								   Sri asks you for friendship!
								  <div class="time">12 Hours Ago</div>
								</div>
							  </a>

							  <a href="#" class="dropdown-item">
								<div class="dropdown-item-icon bg-danger text-white">
								  <i class="fas fa-check"></i>
								</div>
								<div class="dropdown-item-desc">
									Storage has been cleared, now you can get back to work!
								  <div class="time">20 Hours Ago</div>
								</div>
							  </a>

						  
							  <a href="#" class="dropdown-item">
								<div class="dropdown-item-icon bg-info text-white">
								  <i class="fas fa-bell"></i>
								</div>
								<div class="dropdown-item-desc">
								    Welcome to Atrana Template, I hope you enjoy using this template!
								  <div class="time">Yesterday</div>
								</div>
							  </a>
 
							</div>
						</div>

						<div class="dropdown-footer text-center">
						  <a href="#">View All</a>
						</div>

					  
				  </li>
			 
				  <li class="nav-item dropdown">
					<a class="nav-link" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
					  <img src="../assets/images/avatar/avatar-1.png" alt="">
					</a>
					<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
						<a class="dropdown-item" href="my-profile.html"><i class="fa fa-user size-icon-1"></i> <span>My Profile</span></a>
						<a class="dropdown-item" href="settings.html"><i class="fa fa-cog size-icon-1"></i> <span>Settings</span></a>
						<hr class="dropdown-divider">
						<a class="dropdown-item" href="#"><i class="fa fa-sign-out-alt  size-icon-1"></i> <span>My Profile</span></a>
					</ul>
				  </li>
			</ul>
		</div>
	</div>

	<!--Sidebar-->


<div class="sidebar transition overlay-scrollbars animate__animated  animate__slideInLeft">
        <div class="sidebar-content"> 
            <div id="sidebar">
            
            <!-- Logo -->
            <div class="logo">
                    <h2 class="mb-4"><img style="width: 150px; height: 150px;" src="../assets/images/mylogo.ico"> </h2>
            </div>

            <ul class="side-menu">
                <li>
                    <a href="../star_superviseur.php" class="active">
                        <i class='bx bxs-dashboard icon' ></i> MENU PRINCIPAL
                    </a>
                    <?php include('page.php'); ?>
                </li>

                <!-- Divider-->
                <li class="divider" style="font-size: 18px;" data-text="STARTER"> DEBARQUEMENT</li>

                <li>
                    <a href="#">
                        <i class='bx bx-columns icon' ></i> 
                        Enregistrement des bons de Transfert / Livraison
                        <i class='bx bx-chevron-right icon-right' ></i>
                    </a>
                    <ul class="side-dropdown">
                       
                        
                                                
                    </ul>
                </li>

                       <li><a id="varier" data-bs-toggle="modal" data-bs-target="#Les_avaries">
                        <i class='bx bx-columns icon' ></i>AJOUTER SITUATION
                       </a>
                   </li> 
                   

                    <li><a   href="tr.situations.php"> <i class='bx bx-columns icon' ></i> MES SITUATION</a></li>
                    </a>
                     <li><a href="final_report.php"> <i class='bx bx-columns icon' ></i> FINAL REPORT</a></li>
                    </a>
                    
                       

 
 


                
               

                <!-- Divider-->
       </div> 
     </div>
    </div><!-- End Sidebar-->


    <div class="sidebar-overlay"></div>
    

	
<div class="modal fade" id="modif_register" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content" style=" border: solid; border-color:rgb(0,141,202); ">
            <div class="modal-header" style="">
              <center>
                <h3 class="modal-title fs-10 text-white text-center" id="exampleModalLabel " style="text-align:center;   ">MODIFICATION</h3></center>
                <center>
              <img class="logoo" src="../images/mylogo.ico" >
       </center>
        
      </div>
       <br> <br>
        <form  method="POST">





   <div class="mb-3">
    
   <label>DATE</label>  
  <input type="text" class="form-control"  id="date_m_rm"  name="conditionnement"  > <br>
  <label>HEURE</label>  
  <input type="time" class="form-control"  id="heure_m_rm"  name="conditionnement"  > <br>
    <label>BL</label>  
  <input type="text" class="form-control"  id="bl_m_rm"  name="conditionnement"  > <br>
  <label>SAC</label>  
  <input type="text" class="form-control"  id="sac_m_rm"  name="conditionnement"  > <br>
  <input type="text" class="form-control"  id="id_m_rm" hidden="true"  name="conditionnement"  >
<label>DECLARATION</label>
   <select id="declaration_m_rm">
  
  </select><br> 
  <label>CALE</label>
   <select id="cale_m_rm">
   
  </select>

<div style="background: blue">
   <div class="mb-3">
      <center>  
    <h3 style="background: white; color: blue;">TRANSPORT</h3>
   
 <label style="color: white;">CAMIONS  </label><br> 
  </center> 
  

   
<input type="text" id="myInput_m_rm"  placeholder="SAISIR LE N° DE CAMION" style="width: 50%; " onkeyup="filtreca_m_rm();" ><br><br>

<label style="color: white;">TRANSPORTEUR  </label><br> 
<input type="text" id="myInputTransp_m_rm" placeholder="transporteur" style="width: 50%; " disabled="true" >


<div id="camionList_m_rm" style="background: white; display: none; " >
  </div>
 



<input type="" name="input2" id="val_input2_m_rm"   hidden="true"  >

 <center> <br>  
<label style="color: white;">CHAUFFEUR  </label> 
</center> 
 
<input type="text" id="myInputc_m_rm"  placeholder="chauffeur" style="width: 100%;" onkeyup="filtreChau_m_rm();"  >

<div id="camionListc_m_rm" style="background: white; display: none;" >
  

</div>
<input type="" name="input2c" id="val_input2c_m_rm" hidden="true">
<input type=""  id="dis_bl_m_rm" hidden="true" >
<input type=""  id="poids_sac_m_rm" hidden="true" >
  
  </div>

  
</div>
 </div><br> 






   
  
    </center>
    



</center>

        
        
 
       
      <div class="modal-footer">
    <a id="mod"   class="btn btn-primary btn-block btn-lg shadow-lg mt-5" name="modifier_les_register">valider</a>
        </div>
      </div>
      </form>
       </div> 
    </div>
  </div>
</div>



<div class="modal fade" id="modif_register_vrac" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content" style=" border: solid; border-color:rgb(0,141,202); ">
            <div class="modal-header" style="">
              <center>
                <h3 class="modal-title fs-10 text-white text-center" id="exampleModalLabel " style="text-align:center;   ">MODIFICATION</h3></center>
                <center>
              <img class="logoo" src="../images/mylogo.ico" >
       </center>
        
      </div>
       <br> <br>
        <form  method="POST">





   <div class="mb-3">
    
   <label>DATE</label>  
  <input type="text" class="form-control"  id="date_m_vrac"  name="conditionnement"  > <br>
  <label>HEURE</label>  
  <input type="time" class="form-control"  id="heure_m_vrac"  name="conditionnement"  > <br>
    <label>BL</label>  
  <input type="text" class="form-control"  id="bl_m_vrac"  name="conditionnement"  > <br>
  <label>SAC</label>  
  <input type="text" class="form-control"  id="sac_m_vrac"  name="conditionnement"  > <br>
    <label>POIDS</label>  
  <input type="text" class="form-control"  id="poids_m_vrac"  name="conditionnement"  > <br>
  <input type="text" class="form-control"  id="id_m_vrac"  name="conditionnement"  >
<label>DECLARATION</label>
   <select id="declaration_m_vrac">
  
  </select><br> 
  <label>CALE</label>
   <select id="cale_m_vrac">
   
  </select>

<div style="background: blue">
   <div class="mb-3">
      <center>  
    <h3 style="background: white; color: blue;">TRANSPORT</h3>
   
 <label style="color: white;">CAMIONS  </label><br> 
  </center> 
  

   
<input type="text" id="myInput_m_vrac"  placeholder="SAISIR LE N° DE CAMION" style="width: 50%; " onkeyup="filtreca_m_vrac();" autocomplete="none"><br><br>

<label style="color: white;">TRANSPORTEUR  </label><br> 
<input type="text" id="myInputTransp_m_vrac" placeholder="transporteur" style="width: 50%; " disabled="true" >


<div id="camionList_m_vrac" style="background: white; display: none; " >
  </div>
 



<input type="" name="input2" id="val_input2_m_vrac"  hidden="true"   >

 <center> <br>  
<label style="color: white;">CHAUFFEUR </label> 
</center> 
 
<input type="text" id="myInputc_m_vrac"  placeholder="chauffeur" style="width: 100%;" onkeyup="filtreChau_m_vrac();" autocomplete="none">

<div id="camionListc_m_vrac" style="background: white; display: none;" >
  

</div>
<input type="" name="input2c" id="val_input2c_m_vrac" hidden="true" >
<input type=""  id="dis_bl_m_vrac" hidden="true" >
<input type=""  id="poids_sac_m_vrac" hidden="true" >
  
  </div>

  
</div>
 </div><br> 






   
  
    </center>
    



</center>

        
        
 
       
      <div class="modal-footer">
    <a id="mod_vrac"   class="btn btn-primary btn-block btn-lg shadow-lg mt-5" name="modifier_les_register">valider</a>
        </div>
      </div>
      </form>
       </div> 
    </div>
  </div>
</div>





<div class="modal fade" id="modif_register_vrac0" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content" style=" border: solid; border-color:rgb(0,141,202); ">
            <div class="modal-header" style="">
              <center>
                <h3 class="modal-title fs-10 text-white text-center" id="exampleModalLabel " style="text-align:center;   ">MODIFICATION</h3></center>
                <center>
              <img class="logoo" src="../images/mylogo.ico" >
       </center>
        
      </div>
       <br> <br>
        <form  method="POST">





   <div class="mb-3">
    
   <label>DATE</label>  
  <input type="text" id="date_m_vrac0" class="form-control"    name="co"  > <br>
  <label>HEURE</label>  
  <input type="time" class="form-control"  id="heure_m_vrac0"  name="conditionnement"  > <br>
    <label>BL</label>  
  <input type="text" class="form-control"  id="bl_m_vrac0"  name="conditionnement"  > <br>
 
    <label>POIDS</label>  
  <input type="text" class="form-control"  id="poids_m_vrac0"  name="conditionnement"  > <br>
  <input type="text" class="form-control"  id="id_m_vrac0"  name="conditionnement"  >
<label>DECLARATION</label>
   <select id="declaration_m_vrac0">
  
  </select><br> 
  <label>CALE</label>
   <select id="cale_m_vrac0">
   
  </select>

<div style="background: blue">
   <div class="mb-3">
      <center>  
    <h3 style="background: white; color: blue;">TRANSPORT</h3>
   
 <label style="color: white;">CAMIONS </label><br> 
  </center> 
  

   
<input type="text" id="myInput_m_vrac0"  placeholder="SAISIR LE N° DE CAMION" style="width: 50%; " onkeyup="filtreca_m_vrac0();" autocomplete="none"><br><br>

<label style="color: white;">TRANSPORTEUR  </label><br> 
<input type="text" id="myInputTransp_m_vrac0" placeholder="transporteur" style="width: 50%; " disabled="true" >


<div id="camionList_m_vrac0" style="background: white; display: none; " >
  </div>
 



<input type="" name="input2" id="val_input2_m_vrac0" hidden="true"  >

 <center> <br>  
<label style="color: white;">CHAUFFEUR  </label> 
</center> 
 
<input type="text" id="myInputc_m_vrac0"  placeholder="chauffeur" style="width: 100%;" onkeyup="filtreChau_m_vrac0();" autocomplete="none" >

<div id="camionListc_m_vrac0" style="background: white; display: none;" >
  

</div>
<input type="" name="input2c" id="val_input2c_m_vrac0" hidden="true" >
<input type=""  id="dis_bl_m_vrac0" hidden="true">
<input type=""  id="poids_sac_m_vrac0" hidden="true">
  
  </div>

  
</div>
 </div><br> 






   
  
    </center>
    



</center>

        
        
 
       
      <div class="modal-footer">
    <a id="mod_vrac0"   class="btn btn-primary btn-block btn-lg shadow-lg mt-5" name="modifier_les_register">valider</a>
        </div>
      </div>
      </form>
       </div> 
    </div>
  </div>
</div>




<div class="modal fade" id="modif_register_avaries" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content" style=" border: solid; border-color:rgb(0,141,202); ">
            <div class="modal-header" style="">
              <center>
                <h3 class="modal-title fs-10 text-white text-center" id="exampleModalLabel " style="text-align:center;   ">MODIFICATION</h3></center>
                <center>
              <img class="logoo" src="../images/mylogo.ico" >
       </center>
        
      </div>
       <br> <br>
        <form  method="POST">





   <div class="mb-3">
    
   <label>DATE</label>  
  <input type="text" class="form-control"  id="date_m_av"  name="conditionnement"  > <br>
  <label>HEURE</label>  
  <input type="time" class="form-control"  id="heure_m_av"  name="conditionnement"  > <br>
   
<label>DECLARATION</label><br>
   <select id="declaration_m_av">
  
  </select><br> 
  <label>CALE</label><br>
   <select id="cale_m_av">
   
  </select><br>
</div>

<div style="background: blue">
   <div class="mb-3">
      <center>  
    <h3 style="background: white; color: blue ;">TRANSPORT</h3>
   
 <label style="color: white !important;">CAMIONS  </label><br> 
  </center> 
  

   
<input type="text" id="myInput_m_av"  placeholder="SAISIR LE N° DE CAMION" style="width: 50%; " onkeyup="filtreca_m_av();" ><br><br>

<label style="color: white !important;">TRANSPORTEUR  </label><br> 
<input type="text" id="myInputTransp_m_av" placeholder="transporteur" style="width: 50%; " disabled="true" >


<div id="camionList_m_av" style="background: white; display: none; " >
  </div>
 



<input type="" name="input2" id="val_input2_m_av" hidden="true" >

 <center> <br>  
<label style="color: white !important;">CHAUFFEUR  </label> 
</center> 
 
<input type="text" id="myInputc_m_av"  placeholder="chauffeur" style="width: 100%;" onkeyup="filtreChau_m_av();" >

<div id="camionListc_m_av" style="background: white; display: none;" >
  

</div>
<input type="" name="input2c" id="val_input2c_m_av" hidden="true" >
<input type=""  id="dis_bl_m_av" hidden="true" >
<input type=""  id="poids_sac_m_av" hidden="true" ><br><br>

  </div>

  
</div>
<div class="mb-3">

 <label style="">BL</label><br>  
  <input type="text" class="form-control"  id="bl_m_av"  name="conditionnement"  > <br>
  <label style="">SACS FLASQUE</label> <br> 
  <input type="text" class="form-control"  id="sacf_m_av"  name="conditionnement"  > <br>
  <label style="">POIDS FLASQUE</label><br>  
  <input type="text" class="form-control"  id="poidsf_m_av"  name="conditionnement"  > <br>
  <label style="">SACS MOUILLE</label><br>  
  <input type="text" class="foav-control"  id="sacm_m_av"  name="conditionnement"  > <br>
  <label hidden="true" style="">POIDS MOUILLE</label><br>  
  <input type="text" class="form-control"  id="poidsm_m_av"  name="conditionnement" hidden='true' > <br>
  <input type="text" class="form-control"  id="id_m_av"  name="conditionnement" hidden="true"  >
  
  </div>

  
<br> 






   
  
    </center>
    



</center>

        
        
 
       
      <div class="modal-footer">
    <a id="mod_avaries"   class="btn btn-primary btn-block btn-lg shadow-lg mt-5" name="modifier_les_register">valider</a>
        </div>
      </div>
      </form>
       </div> 
    </div>
  </div>
</div>




<div class="modal fade" id="modif_avaries_deb" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content" style=" border: solid; border-color:rgb(0,141,202); ">
            <div class="modal-header" style="">
              <center>
                <h3 class="modal-title fs-10 text-white text-center" id="exampleModalLabel " style="text-align:center;   ">MODIFICATION</h3></center>
                <center>
              <img class="logoo" src="../images/mylogo.ico" >
       </center>
        
      </div>
       <br> <br>
        <form  method="POST">





   <div class="mb-3">
    
   <label>DATE</label>  
  <input  type="text"  id="date_avdeb"   class="form-control" > <br>
 
 <label style="">SACS FLASQUE</label> <br> 
  <input type="text" class="form-control"  id="sacf_avdeb"  name="conditionnement"  > <br>
   <label style="">SACS MOUILLE</label> <br> 
  <input type="text" class="form-control"  id="sacm_avdeb"  name="conditionnement"  > <br>
  <label style="">id_navire</label> <br> 
  <input type="text" class="form-control"  id="id_navire_avdeb"  name="conditionnement"  > <br>
  <label style="">id</label> <br> 
  <input type="text" class="form-control"  id="id_avdeb"  name="conditionnement"  > <br>
  <label style="">id_dis</label> <br> 
  <input type="text" class="form-control"  id="id_dis_avdeb"  name="conditionnement"  > <br>
  
  </div>

  
<br> 






   
  
    </center>
    



</center>

        
        
 
       
      <div class="modal-footer">
    <a id="mod_avaries_deb"   class="btn btn-primary btn-block btn-lg shadow-lg mt-5" name="modifier_les_register">valider</a>
        </div>
      </div>
      </form>
       </div> 
    </div>
  </div>
</div>




<div class="modal fade" id="modif_avaries_deb2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content" style=" border: solid; border-color:rgb(0,141,202); ">
            <div class="modal-header" style="">
              <center>
                <h3 class="modal-title fs-10 text-white text-center" id="exampleModalLabel " style="text-align:center;   ">MODIFICATION</h3></center>
                <center>
              <img class="logoo" src="../images/mylogo.ico" >
       </center>
        
      </div>
       <br> <br>
        <form  method="POST">





   <div class="mb-3">
    
   <label>DATE</label>  
  <input  type="text"  id="date_avdeb2"   class="form-control" > <br>
 
 <label style="">SACS FLASQUE</label> <br> 
  <input type="text" class="form-control"  id="sacf_avdeb2"  name="conditionnement"  > <br>
   <label style="">SACS MOUILLE</label> <br> 
  <input type="text" class="form-control"  id="sacm_avdeb2"  name="conditionnement"  > <br>
  <label style="">id_navire</label> <br> 
  <input type="text" class="form-control"  id="id_navire_avdeb2"  name="conditionnement"  > <br>
  <label style="">id</label> <br> 
  <input type="text" class="form-control"  id="id_avdeb2"  name="conditionnement"  > <br>
  
  </div>

  
<br> 






   
  
    </center>
    



</center>

        
        
 
       
      <div class="modal-footer">
    <a id="mod_avaries_deb2"   class="btn btn-primary btn-block btn-lg shadow-lg mt-5" name="modifier_les_register">valider</a>
        </div>
      </div>
      </form>
       </div> 
    </div>
  </div>
</div>





	<!--Content Start-->
	<div class="content-start transition">
		<div class="container-fluid dashboard">
			<div class="content-header">

            <div class="col-md-12 col-lg-12">
    <h3 class="operation text-white " style=" font-weight: bold; width: 75%; background: rgb(0,141,202);"  >DEBARQUEMENT</h3>
</div>
<br>
  <div class="container-fluid1  " style="width: 100%; background: rgb(0,141,202);" >
		<div class="row">
			

				<div class="col-lg-12 col-md-12">
					<h1 class="hem" > ENREGISTREMENT DES BONS DE TRANSFERT / LIVRAISON DES SACS SAINS</h1><br>

					
					<form method="POST" >
                        <div>
                            
                           <select  id="navire" class="mysel" style="margin-right: 15%; height: 30px;   width: 40%; " onchange='goNavire()'>
                            <option value="">selectionner une navire</option>
                            <?php 
                            while ($row=$navire->fetch()) {
                             ?>
                                <option  value=<?php echo $row['id']; ?>><?php echo $row['navire']; ?></option>
                            <?php } ?>

                        </select>
                           
                       
                        <select id="produit" class="mysel" name="produit" style="margin-right: 2%; height: 30px;  width: 40%;" onchange='goProduit()'>
                            <option  selected>selectionner produit</option>
  
                        </select>
												
                        </div>
						
                 
							
					</form>
				
			</div>
		</div>
	</div>
	<br><br>

  
     <div class="main" id="main">

     
        
      


    <?php 
//111111111111111111111111111DEBUTPARTIE11111111111111111111111111111 
    //       PARTIE SITUATION DEBARQUEMENT
     ?>
     <div >
        
         

</div>

    <br><br>
    <div class="sit" id="sit">
    </div>
    </div>








        
	<?php 
    


if(isset($_POST['valider_Avaries']) ){
    if(!empty($_POST['produit']) and !empty($_POST['poids']) and !empty($_POST['cond']) and !empty($_POST['cale']) and !empty($_POST['id_dis_dis']) and !empty($_POST['id_client_dis']) and !empty($_POST['id_mangasin_dis']) and !empty($_POST['id_poids_dis']) and !empty($_POST['id_produit_dis']) and !empty($_POST['id_navire_dis']) ){
        //$nav=$_POST['navire'];
       
        $produit=$_POST['produit'];
        //$nombre_sac=$_POST['nombre_sac'];
        $poids=$_POST['cond'];
        $navire=$_POST['navire'];
         $sacf=$_POST['nombre_sacf'];
        $sacm=$_POST['nombre_sacm'];
        $cale=$_POST['cale'];
        $date=$_POST['date'];
        $id_produit=$_POST['id_produit'];
        $ref=0;
        $id_dis=$_POST['id_di'];

        
        
          $insertRecep1= $bdd->prepare("INSERT INTO avaries(date_avaries,cale_avaries,sac_flasque,poids_flasque,sac_mouille,poids_mouille,poids_sac_avaries,id_produit,id_navire,id_dis_av,ref) VALUES(?,?,?,?,?,?,?,?,?,?,?)"); 

           $insertRecep5= $bdd->prepare("INSERT INTO avaries(date_avaries,cale_avaries,sac_flasque,poids_flasque,sac_mouille,poids_mouille,poids_sac_avaries,id_produit,id_navire,id_dis_av,ref) VALUES(?,?,?,?,?,?,?,?,?,?,?)");      

  $produit1=$_POST['produit1'];
        //$nombre_sac=$_POST['nombre_sac'];
        $poids1=$_POST['cond1'];
        //$navire1=$_POST['navire1'];
        
        $cale1=$_POST['cale1'];

        $date1="0000-00-00";
        $zero=0;
        $null="ref";
        $h="00:00:00";
        
          $insertRecep2= $bdd->prepare("INSERT INTO register_manifeste(dates,heure,cale,bl,id_dis_bl,camions,chauffeur,id_declaration,sac,poids,id_produit,poids_sac,id_client,id_destination,id_navire,destinataire) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");      

     $insertRecep3= $bdd->prepare("INSERT INTO register_manifeste(dates,heure,cale,bl,id_dis_bl,camions,chauffeur,id_declaration,sac,poids,id_produit,poids_sac,id_client,id_destination,id_navire,destinataire) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"); 

     $insertRecep4= $bdd->prepare("INSERT INTO transfert_avaries(date_tr_avaries,heure_tr,cale_tr_avaries,bl_tr,id_cam,id_chauffeur_tr,sac_flasque_tr_av,poids_flasque_tr_av,sac_mouille_tr_av,poids_mouille_tr_av,id_dis_bl_tr,id_declaration_tr,poids_sac_tr_av,id_produit,id_client,id_destination_tr,id_navire,autre_destination_tr,destinataire_tr) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"); 


     $produit3=$_POST['id_produit_dis'];
     $nav3=$_POST['id_navire_dis'];
     $client3=$_POST['id_client_dis'];
     $mangasin3=$_POST['id_mangasin_dis'];
     $poids3=$_POST['id_poids_dis'];
     $id_dis3=$_POST['id_dis_dis'];
     $statut="debarquement";

              try{
       $insertdate= $bdd->prepare("INSERT INTO date_situation(date_sit,id_navire_sit) VALUES(?,?)");
       $insertdate->bindParam(1,$date); 
       $insertdate->bindParam(2,$navire);
       $insertdate->execute(); 



    foreach ($produit as $key=>$prod) {
    
   // $nombre=$nombre_sac[$key];
    $ps=$poids[$key];
    $sf=$sacf[$key];
    $sm=$sacm[$key];
    $id_prod=$id_produit[$key];
    
    $cal=$cale[$key];

    $poidsf=$sf*$ps/1000;
     $poidsm=$sm*$ps/1000;
    

                    $insertRecep1->bindParam(1,$date); 
$insertRecep1->bindParam(2,$cal);

$insertRecep1->bindParam(3,$sf);
$insertRecep1->bindParam(4,$poidsf);
$insertRecep1->bindParam(5,$sm);
$insertRecep1->bindParam(6,$poidsm);
$insertRecep1->bindParam(7,$ps);
$insertRecep1->bindParam(8,$prod);
$insertRecep1->bindParam(9,$navire);
$insertRecep1->bindParam(10,$zero);
$insertRecep1->bindParam(11,$ref);

$insertRecep1->execute();
    
 
    }
    

foreach ($produit1 as $key=>$prod1) {
     $ps1=$poids1[$key];
    
    $cal1=$cale1[$key];   

    $insertRecep2->bindParam(1,$date); 
$insertRecep2->bindParam(2,$h);

$insertRecep2->bindParam(3,$cal1);
$insertRecep2->bindParam(4,$null);
$insertRecep2->bindParam(5,$zero);
$insertRecep2->bindParam(6,$null);
$insertRecep2->bindParam(7,$null);


$insertRecep2->bindParam(8,$zero);
$insertRecep2->bindParam(9,$zero);
$insertRecep2->bindParam(10,$zero);

$insertRecep2->bindParam(11,$prod1);
$insertRecep2->bindParam(12,$ps1);
$insertRecep2->bindParam(13,$zero);
$insertRecep2->bindParam(14,$zero);
$insertRecep2->bindParam(15,$navire);
$insertRecep2->bindParam(16,$null);


$insertRecep2->execute();
}

    

    


     foreach ($produit3 as $key=>$prod3) {
     $ps3=$poids3[$key];
     $cli=$client3[$key];
     $mang=$mangasin3[$key];
     $nav=$nav3[$key];
     $iddis=$id_dis3[$key];
     
      

    $insertRecep3->bindParam(1,$date); 
$insertRecep3->bindParam(2,$h);

$insertRecep3->bindParam(3,$null);
$insertRecep3->bindParam(4,$null);
$insertRecep3->bindParam(5,$iddis);
$insertRecep3->bindParam(6,$null);
$insertRecep3->bindParam(7,$null);


$insertRecep3->bindParam(8,$zero);
$insertRecep3->bindParam(9,$zero);
$insertRecep3->bindParam(10,$zero);

$insertRecep3->bindParam(11,$prod3);
$insertRecep3->bindParam(12,$ps3);
$insertRecep3->bindParam(13,$cli);
$insertRecep3->bindParam(14,$mang);
$insertRecep3->bindParam(15,$nav);
$insertRecep3->bindParam(16,$null);

$insertRecep3->execute();



$insertRecep4->bindParam(1,$date); 
$insertRecep4->bindParam(2,$h);

$insertRecep4->bindParam(3,$null);
$insertRecep4->bindParam(4,$null);

$insertRecep4->bindParam(5,$null);
$insertRecep4->bindParam(6,$null);
$insertRecep4->bindParam(7,$zero);
$insertRecep4->bindParam(8,$zero);
$insertRecep4->bindParam(9,$zero);

$insertRecep4->bindParam(10,$zero);
$insertRecep4->bindParam(11,$iddis);
$insertRecep4->bindParam(12,$zero);
$insertRecep4->bindParam(13,$ps3);
$insertRecep4->bindParam(14,$prod3); 
$insertRecep4->bindParam(15,$cli);
$insertRecep4->bindParam(16,$mang);
$insertRecep4->bindParam(17,$nav);
$insertRecep4->bindParam(18,$null);
$insertRecep4->bindParam(19,$null);
$insertRecep4->execute();



$insertRecep5->bindParam(1,$date); 
$insertRecep5->bindParam(2,$ref);

$insertRecep5->bindParam(3,$null);
$insertRecep5->bindParam(4,$null);

$insertRecep5->bindParam(5,$null);
$insertRecep5->bindParam(6,$null);
$insertRecep5->bindParam(7,$ps3);
$insertRecep5->bindParam(8,$prod3);
$insertRecep5->bindParam(9,$nav);

$insertRecep5->bindParam(10,$iddis);
$insertRecep5->bindParam(11,$ref);

$insertRecep5->execute();


}
}
    catch(Exception $e){

    }
 

      $message2="reussie";
   
    }

    else{
         $message2="Veuillez choisir un produit existant";
    }
    frontend();

}





if(isset($_POST['valider_Avaries3']) ){
    if(!empty($_POST['date'])   and !empty($_POST['cale']) ){
        //$nav=$_POST['navire'];
       
        $id_dis=$_POST['id_di'];
        //$nombre_sac=$_POST['nombre_sac'];
        $poids=$_POST['poids_sac'];
        $navire=$_POST['navire'];
         $sacf=$_POST['sacf'];
        $sacm=$_POST['sacm'];
        $cale=$_POST['cale'];
        $date=$_POST['date'];
        $id_produit=$_POST['id_produit'];
        $poidsf=$sacf*$poids/1000;
        $poidsm=$sacm*$poids/1000;
        $ref=1;

        
 try{       
          $insertRecep1= $bdd->prepare("INSERT INTO avaries(date_avaries,cale_avaries,sac_flasque,poids_flasque,sac_mouille,poids_mouille,poids_sac_avaries,id_produit,id_navire,id_dis_av,ref) VALUES(?,?,?,?,?,?,?,?,?,?,?)");      



      
                  $insertRecep1->bindParam(1,$date); 
              $insertRecep1->bindParam(2,$cale);

$insertRecep1->bindParam(3,$sacf);
$insertRecep1->bindParam(4,$poidsf);
$insertRecep1->bindParam(5,$sacm);
$insertRecep1->bindParam(6,$poidsm);
$insertRecep1->bindParam(7,$poids);
$insertRecep1->bindParam(8,$id_produit);
$insertRecep1->bindParam(9,$navire);
$insertRecep1->bindParam(10,$id_dis);
$insertRecep1->bindParam(11,$ref);

$insertRecep1->execute();
    
 
    }
    



    catch(Exception $e){

    }
 

      $message2="reussie";
   
    }

    else{
         $message2="ERREUR";
    }

    $_SESSION['visible']=3;
    frontend();
   

}







if(isset($_POST['valider_Avaries2']) ){
    if( !empty($_POST['id_dis_dis']) and !empty($_POST['id_client_dis']) and !empty($_POST['id_mangasin_dis']) and !empty($_POST['id_poids_dis']) and !empty($_POST['id_produit_dis']) and !empty($_POST['id_navire_dis']) ){
        //$nav=$_POST['navire'];
       

        $navire=$_POST['navire'];
       
      
        $date=$_POST['date'];
     

        
        
              

  $produit1=$_POST['produit1'];
        //$nombre_sac=$_POST['nombre_sac'];
        $poids1=$_POST['cond1'];
        //$navire1=$_POST['navire1'];
        
        $cale1=$_POST['cale1'];

        $date1="0000-00-00";
        $zero=0;
        $null="ref";
        $h="00:00:00";
        
          $insertRecep2= $bdd->prepare("INSERT INTO register_manifeste(dates,heure,cale,bl,id_dis_bl,camions,chauffeur,id_declaration,sac,poids,id_produit,poids_sac,id_client,id_destination,id_navire,destinataire) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");      

     $insertRecep3= $bdd->prepare("INSERT INTO register_manifeste(dates,heure,cale,bl,id_dis_bl,camions,chauffeur,id_declaration,sac,poids,id_produit,poids_sac,id_client,id_destination,id_navire,destinataire) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"); 

     
     $produit3=$_POST['id_produit_dis'];
     $nav3=$_POST['id_navire_dis'];
     $client3=$_POST['id_client_dis'];
     $mangasin3=$_POST['id_mangasin_dis'];
     $poids3=$_POST['id_poids_dis'];
     $id_dis3=$_POST['id_dis_dis'];

              try{
 $insertdate= $bdd->prepare("INSERT INTO date_situation(date_sit,id_navire_sit) VALUES(?,?)");
       $insertdate->bindParam(1,$date); 
       $insertdate->bindParam(2,$navire);
       $insertdate->execute();

   
foreach ($produit1 as $key=>$prod1) {
     $ps1=$poids1[$key];
    
    $cal1=$cale1[$key];   

    $insertRecep2->bindParam(1,$date); 
$insertRecep2->bindParam(2,$h);

$insertRecep2->bindParam(3,$cal1);
$insertRecep2->bindParam(4,$null);
$insertRecep2->bindParam(5,$zero);
$insertRecep2->bindParam(6,$null);
$insertRecep2->bindParam(7,$null);


$insertRecep2->bindParam(8,$zero);
$insertRecep2->bindParam(9,$zero);
$insertRecep2->bindParam(10,$zero);

$insertRecep2->bindParam(11,$prod1);
$insertRecep2->bindParam(12,$ps1);
$insertRecep2->bindParam(13,$zero);
$insertRecep2->bindParam(14,$zero);
$insertRecep2->bindParam(15,$navire);
$insertRecep2->bindParam(16,$null);


$insertRecep2->execute();
}

    

    


     foreach ($produit3 as $key=>$prod3) {
     $ps3=$poids3[$key];
     $cli=$client3[$key];
     $mang=$mangasin3[$key];
     $nav=$nav3[$key];
     $iddis=$id_dis3[$key];
     
      

    $insertRecep3->bindParam(1,$date); 
$insertRecep3->bindParam(2,$h);

$insertRecep3->bindParam(3,$null);
$insertRecep3->bindParam(4,$null);
$insertRecep3->bindParam(5,$iddis);
$insertRecep3->bindParam(6,$null);
$insertRecep3->bindParam(7,$null);


$insertRecep3->bindParam(8,$zero);
$insertRecep3->bindParam(9,$zero);
$insertRecep3->bindParam(10,$zero);

$insertRecep3->bindParam(11,$prod3);
$insertRecep3->bindParam(12,$ps3);
$insertRecep3->bindParam(13,$cli);
$insertRecep3->bindParam(14,$mang);
$insertRecep3->bindParam(15,$nav);
$insertRecep3->bindParam(16,$null);

$insertRecep3->execute();



  
}
}
    catch(Exception $e){

    }
 

      $message2="reussie";
   
    }

    else{
         $message2="Veuillez choisir un produit existant";
    }

}

















 ?>	

	<!-- Footer -->				
	<footer>
		<div class="footer">
			<div class="float-start">
				<p>2023 &copy; Ibradev</p>
			</div>
				<div class="float-end">
					<p>Created with 
						<span class="text-danger">
							<i class="fa fa-heart"></i> by 
							<a href="https://www.facebook.com/andreew.co.id/" class="author-footer">Ibradev</a>
						</span> 
					</p>
			</div>
		</div>
	</footer>


	<!-- Preloader -->
	<div class="loader">
		<div class="spinner-border text-light" role="status">
			<span class="sr-only">Loading...</span>
		</div>
	</div>
	
	<!-- Loader -->
	<div class="loader-overlay"></div>

	<!-- General JS Scripts -->
       <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script src="../assets/js/atrana.js"></script>

	<!-- JS Libraies -->
	<script src="../assets/modules/jquery/jquery.min.js"></script>

	<script src="../assets/modules/bootstrap-5.1.3/js/bootstrap.bundle.min.js"></script>
	<script src="../assets/modules/popper/popper.min.js"></script>

	<!-- Chart Js -->
	<script src="../assets/modules/apexcharts/apexcharts.js"></script>
	<script src="../assets/js/ui-apexcharts.js"></script>

    <!-- Template JS File -->
	<script src="../assets/js/script.js"></script>
	<script src="../assets/js/custom.js"></script>
   
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>


 
   

<script type="text/javascript"> 
      function filtreca() {
        var search = document.getElementById('myInput').value;
        var camionList = document.getElementById('camionList');
        camionList.style.display="block";
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'action.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
          if (xhr.readyState === 4 && xhr.status === 200) {
            camionList.innerHTML = xhr.responseText;
          }
        };
        xhr.send('query=' + search);
      }

       function stockerIds(element) {
    var camionId = element.id;
    var input2 = document.getElementById("val_input2");
    input2.value = camionId;

   /* var camionText = element.innerText;
    var input = document.getElementById("myInput");
    input.value = camionText;
    var div = document.getElementById("camionList");
    div.style.display = "none"; */
    var camtext = document.getElementById("n_camions"+camionId);
    var camionText = camtext.innerText;
    var input = document.getElementById("myInput");
    input.value = camtext.innerText;
    var div = document.getElementById("camionList");
    div.style.display = "none";

    var trtext = document.getElementById("transp"+camionId);
     var transpText = trtext.innerText;
    var input3 = document.getElementById("myInputTransp");
    input3.value = transpText;
     

    
  }
    </script>


 <script type="text/javascript"> 
      function filtreChau() {
        var search = document.getElementById('myInputc').value;
        var camionList = document.getElementById('camionListc');
        camionList.style.display="block";
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'action_chauffeur.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
          if (xhr.readyState === 4 && xhr.status === 200) {
            camionList.innerHTML = xhr.responseText;
          }
        };
        xhr.send('query=' + search);
      }

        function stockerIdc(element) {
    var camionId = element.id;
    var input2 = document.getElementById("val_input2c");
    input2.value = camionId;

    var camionText = element.innerText;
    var input = document.getElementById("myInputc");
    input.value = camionText;
    var div = document.getElementById("camionListc");
    div.style.display = "none";

  input2.value = chauffeurId;

    
  }
    </script>


<script type="text/javascript"> 
      function filtreca3() {
        var search = document.getElementById('myInput3').value;
        var camionList = document.getElementById('camionList3');
        camionList.style.display="block";
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'action3.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
          if (xhr.readyState === 4 && xhr.status === 200) {
            camionList.innerHTML = xhr.responseText;
          }
        };
        xhr.send('query=' + search);
      }

       function stockerIds3(element) {
    var camionId = element.id;
    var input2 = document.getElementById("val_input3");
    input2.value = camionId;

   /* var camionText = element.innerText;
    var input = document.getElementById("myInput");
    input.value = camionText;
    var div = document.getElementById("camionList");
    div.style.display = "none"; */
    var camtext = document.getElementById("n_camions"+camionId);
    var camionText = camtext.innerText;
    var input = document.getElementById("myInput3");
    input.value = camtext.innerText;
    var div = document.getElementById("camionList3");
    div.style.display = "none";

    var trtext = document.getElementById("transp"+camionId);
     var transpText = trtext.innerText;
    var input3 = document.getElementById("myInputTransp3");
    input3.value = transpText;
     

    
  }
    </script>


 <script type="text/javascript"> 
      function filtreChau3() {
        var search = document.getElementById('myInputc3').value;
        var camionList = document.getElementById('camionListc3');
        camionList.style.display="block";
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'action_chauffeur3.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
          if (xhr.readyState === 4 && xhr.status === 200) {
            camionList.innerHTML = xhr.responseText;
          }
        };
        xhr.send('query=' + search);
      }

        function stockerIdc3(element) {
    var camionId = element.id;
    var input2 = document.getElementById("val_input3c");
    input2.value = camionId;

    var camionText = element.innerText;
    var input = document.getElementById("myInputc3");
    input.value = camionText;
    var div = document.getElementById("camionListc3");
    div.style.display = "none";

  input2.value = chauffeurId;

    
  }
    </script>




   
 <script type="text/javascript"> 
      function filtreca_m_rm() {
        var search = document.getElementById('myInput_m_rm').value;
        var camionList = document.getElementById('camionList_m_rm');
        camionList.style.display="block";
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'action_m_rm.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
          if (xhr.readyState === 4 && xhr.status === 200) {
            camionList.innerHTML = xhr.responseText;
          }
        };
        xhr.send('query=' + search);
      }

       function stockerIds_m_rm(element) {
    var camionId = element.id;
    var input2 = document.getElementById("val_input2_m_rm");
    input2.value = camionId;

   /* var camionText = element.innerText;
    var input = document.getElementById("myInput");
    input.value = camionText;
    var div = document.getElementById("camionList");
    div.style.display = "none"; */
    var camtext = document.getElementById("n_camions_m_rm"+camionId);
    var camionText = camtext.innerText;
    var input = document.getElementById("myInput_m_rm");
    input.value = camtext.innerText;
    var div = document.getElementById("camionList_m_rm");
    div.style.display = "none";

    var trtext = document.getElementById("transp_m_rm"+camionId);
     var transpText = trtext.innerText;
    var input3 = document.getElementById("myInputTransp_m_rm");
    input3.value = transpText;
     

    
  }
    </script>



<script type="text/javascript"> 
      function filtreChau_m_rm() {
        var search = document.getElementById('myInputc_m_rm').value;
        var camionList = document.getElementById('camionListc_m_rm');
        camionList.style.display="block";
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'action_chauffeur_m_rm.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
          if (xhr.readyState === 4 && xhr.status === 200) {
            camionList.innerHTML = xhr.responseText;
          }
        };
        xhr.send('query=' + search);
      }

        function stockerIdcm(element) {
    var camionId = element.id;
    var input2 = document.getElementById("val_input2c_m_rm");
    input2.value = camionId;

    var camionText = element.innerText;
    var input = document.getElementById("myInputc_m_rm");
    input.value = camionText;
    var div = document.getElementById("camionListc_m_rm");
    div.style.display = "none";

  input2.value = chauffeurId;

    
  }
    </script>



    <script type="text/javascript"> 
      function filtreca_m_av() {
        var search = document.getElementById('myInput_m_av').value;
        var camionList = document.getElementById('camionList_m_av');
        camionList.style.display="block";
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'action_m_av.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
          if (xhr.readyState === 4 && xhr.status === 200) {
            camionList.innerHTML = xhr.responseText;
          }
        };
        xhr.send('query=' + search);
      }

       function stockerIds_m_av(element) {
    var camionId = element.id;
    var input2 = document.getElementById("val_input2_m_av");
    input2.value = camionId;

   /* var camionText = element.innerText;
    var input = document.getElementById("myInput");
    input.value = camionText;
    var div = document.getElementById("camionList");
    div.style.display = "none"; */
    var camtext = document.getElementById("n_camions_m_av"+camionId);
    var camionText = camtext.innerText;
    var input = document.getElementById("myInput_m_av");
    input.value = camtext.innerText;
    var div = document.getElementById("camionList_m_av");
    div.style.display = "none";

    var trtext = document.getElementById("transp_m_av"+camionId);
     var transpText = trtext.innerText;
    var input3 = document.getElementById("myInputTransp_m_av");
    input3.value = transpText;
     

    
  }
    </script>


<script type="text/javascript"> 
      function filtreChau_m_av() {
        var search = document.getElementById('myInputc_m_av').value;
        var camionList = document.getElementById('camionListc_m_av');
        camionList.style.display="block";
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'action_chauffeur_m_av.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
          if (xhr.readyState === 4 && xhr.status === 200) {
            camionList.innerHTML = xhr.responseText;
          }
        };
        xhr.send('query=' + search);
      }

        function stockerIdcav(element) {
    var camionId = element.id;
    var input2 = document.getElementById("val_input2c_m_av");
    input2.value = camionId;

    var camionText = element.innerText;
    var input = document.getElementById("myInputc_m_av");
    input.value = camionText;
    var div = document.getElementById("camionListc_m_av");
    div.style.display = "none";

  input2.value = chauffeurId;

    
  }
    </script>




    <script type="text/javascript"> 
      function filtreca_m_vrac() {
        var search = document.getElementById('myInput_m_vrac').value;
        var camionList = document.getElementById('camionList_m_vrac');
        camionList.style.display="block";
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'action_m_vrac.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
          if (xhr.readyState === 4 && xhr.status === 200) {
            camionList.innerHTML = xhr.responseText;
          }
        };
        xhr.send('query=' + search);
      }

       function stockerIds_m_vrac(element) {
    var camionId = element.id;
    var input2 = document.getElementById("val_input2_m_vrac");
    input2.value = camionId;

   /* var camionText = element.innerText;
    var input = document.getElementById("myInput");
    input.value = camionText;
    var div = document.getElementById("camionList");
    div.style.display = "none"; */
    var camtext = document.getElementById("n_camions_m_vrac"+camionId);
    var camionText = camtext.innerText;
    var input = document.getElementById("myInput_m_vrac");
    input.value = camtext.innerText;
    var div = document.getElementById("camionList_m_vrac");
    div.style.display = "none";

    var trtext = document.getElementById("transp_m_vrac"+camionId);
     var transpText = trtext.innerText;
    var input3 = document.getElementById("myInputTransp_m_vrac");
    input3.value = transpText;
     

    
  }
    </script>



<script type="text/javascript"> 
      function filtreChau_m_vrac() {
        var search = document.getElementById('myInputc_m_vrac').value;
        var camionList = document.getElementById('camionListc_m_vrac');
        camionList.style.display="block";
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'action_chauffeur_m_vrac.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
          if (xhr.readyState === 4 && xhr.status === 200) {
            camionList.innerHTML = xhr.responseText;
          }
        };
        xhr.send('query=' + search);
      }

        function stockerIdcvrac(element) {
    var camionId = element.id;
    var input2 = document.getElementById("val_input2c_m_vrac");
    input2.value = camionId;

    var camionText = element.innerText;
    var input = document.getElementById("myInputc_m_vrac");
    input.value = camionText;
    var div = document.getElementById("camionListc_m_vrac");
    div.style.display = "none";

  input2.value = chauffeurId;

    
  }
    </script>

<script type="text/javascript"> 
      function filtreca_m_vrac0() {
        var search = document.getElementById('myInput_m_vrac0').value;
        var camionList = document.getElementById('camionList_m_vrac0');
        camionList.style.display="block";
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'action_m_vrac0.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
          if (xhr.readyState === 4 && xhr.status === 200) {
            camionList.innerHTML = xhr.responseText;
          }
        };
        xhr.send('query=' + search);
      }

       function stockerIds_m_vrac0(element) {
    var camionId = element.id;
    var input2 = document.getElementById("val_input2_m_vrac0");
    input2.value = camionId;

   /* var camionText = element.innerText;
    var input = document.getElementById("myInput");
    input.value = camionText;
    var div = document.getElementById("camionList");
    div.style.display = "none"; */
    var camtext = document.getElementById("n_camions_m_vrac0"+camionId);
    var camionText = camtext.innerText;
    var input = document.getElementById("myInput_m_vrac0");
    input.value = camtext.innerText;
    var div = document.getElementById("camionList_m_vrac0");
    div.style.display = "none";

    var trtext = document.getElementById("transp_m_vrac0"+camionId);
     var transpText = trtext.innerText;
    var input3 = document.getElementById("myInputTransp_m_vrac0");
    input3.value = transpText;
     

    
  }
    </script>



    <script type="text/javascript"> 
      function filtreChau_m_vrac0() {
        var search = document.getElementById('myInputc_m_vrac0').value;
        var camionList = document.getElementById('camionListc_m_vrac0');
        camionList.style.display="block";
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'action_chauffeur_m_vrac0.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
          if (xhr.readyState === 4 && xhr.status === 200) {
            camionList.innerHTML = xhr.responseText;
          }
        };
        xhr.send('query=' + search);
      }

        function stockerIdcvrac0(element) {
    var camionId = element.id;
    var input2 = document.getElementById("val_input2c_m_vrac0");
    input2.value = camionId;

    var camionText = element.innerText;
    var input = document.getElementById("myInputc_m_vrac0");
    input.value = camionText;
    var div = document.getElementById("camionListc_m_vrac0");
    div.style.display = "none";

  input2.value = chauffeurId;

    
  }
    </script>




  <script type='text/javascript'>
 
            function getXhr(){
                                var xhr = null; 
                if(window.XMLHttpRequest) // Firefox et autres
                   xhr = new XMLHttpRequest(); 
                else if(window.ActiveXObject){ // Internet Explorer 
                   try {
                            xhr = new ActiveXObject("Msxml2.XMLHTTP");
                        } catch (e) {
                            xhr = new ActiveXObject("Microsoft.XMLHTTP");
                        }
                }
                else { // XMLHttpRequest non supporté par le navigateur 
                   alert("Votre navigateur ne supporte pas les objets XMLHTTPRequest..."); 
                   xhr = false; 
                } 
                                return xhr;
            }
 
            /**
            * Méthode qui sera appelée sur le clic du bouton
            */
            function goNavire(){
                var xhr = getXhr();
                // On définit ce qu'on va faire quand on aura la réponse
                xhr.onreadystatechange = function(){
                    // On ne fait quelque chose que si on a tout reçu et que le serveur est OK
                    if(xhr.readyState == 4 && xhr.status == 200){
                        leselect = xhr.responseText;
                        // On se sert de innerHTML pour rajouter les options à la liste
                       // leselect2 = xhr.responseText;

                        document.getElementById('produit').innerHTML = leselect;
                        //document.getElementById('varier').innerHTML = leselect2;

                    }
                }
 
                // Ici on va voir comment faire du post
                xhr.open("POST","selectProduit.php",true);
                // ne pas oublier ça pour le post
                xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
                // ne pas oublier de poster les arguments
                // ici, l'id de l'auteur
                sel = document.getElementById('navire');
                idnavire = sel.options[sel.selectedIndex].value;
                xhr.send("idNavire="+idnavire);
            }
        </script>

        <script type='text/javascript'>
 
            function getXhr(){
                                var xhr = null; 
                if(window.XMLHttpRequest) // Firefox et autres
                   xhr = new XMLHttpRequest(); 
                else if(window.ActiveXObject){ // Internet Explorer 
                   try {
                            xhr = new ActiveXObject("Msxml2.XMLHTTP");
                        } catch (e) {
                            xhr = new ActiveXObject("Microsoft.XMLHTTP");
                        }
                }
                else { // XMLHttpRequest non supporté par le navigateur 
                   alert("Votre navigateur ne supporte pas les objets XMLHTTPRequest..."); 
                   xhr = false; 
                } 
                                return xhr;
            }
 
            /**
            * Méthode qui sera appelée sur le clic du bouton
            */
            function goProduit(){
                var xhr = getXhr();
                // On définit ce qu'on va faire quand on aura la réponse
                xhr.onreadystatechange = function(){
                    // On ne fait quelque chose que si on a tout reçu et que le serveur est OK
                    if(xhr.readyState == 4 && xhr.status == 200){
                        lecale = xhr.responseText;
                        // On se sert de innerHTML pour rajouter les options à la liste
                        document.getElementById('main').innerHTML = lecale;
                        var front=document.getElementById('frontend');
                        front.style.display="none";

                    }
                }
 
                // Ici on va voir comment faire du post
                xhr.open("POST","selectTable.php",true);
                // ne pas oublier ça pour le post
                xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
                // ne pas oublier de poster les arguments
                // ici, l'id de l'auteur
                sel = document.getElementById('produit');
                idproduit = sel.options[sel.selectedIndex].value;
                xhr.send("idProduit="+idproduit);
            }
        </script>


          <script type='text/javascript'>
 
            function getXhr(){
                                var xhr = null; 
                if(window.XMLHttpRequest) // Firefox et autres
                   xhr = new XMLHttpRequest(); 
                else if(window.ActiveXObject){ // Internet Explorer 
                   try {
                            xhr = new ActiveXObject("Msxml2.XMLHTTP");
                        } catch (e) {
                            xhr = new ActiveXObject("Microsoft.XMLHTTP");
                        }
                }
                else { // XMLHttpRequest non supporté par le navigateur 
                   alert("Votre navigateur ne supporte pas les objets XMLHTTPRequest..."); 
                   xhr = false; 
                } 
                                return xhr;
            }
 
            /**
            * Méthode qui sera appelée sur le clic du bouton
            */
            function func_av_deb(){
                var xhr = getXhr();
                // On définit ce qu'on va faire quand on aura la réponse
                xhr.onreadystatechange = function(){
                    // On ne fait quelque chose que si on a tout reçu et que le serveur est OK
                    if(xhr.readyState == 4 && xhr.status == 200){
                        lecale = xhr.responseText;
                        // On se sert de innerHTML pour rajouter les options à la liste
                        document.getElementById('avaries_debarquement').innerHTML = lecale;
                        
                        //front.style.display="none";

                    }
                }
 
                // Ici on va voir comment faire du post
                xhr.open("POST","select_av_deb.php",true);
                // ne pas oublier ça pour le post
                xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
                // ne pas oublier de poster les arguments
                // ici, l'id de l'auteur
                var nav=document.getElementById('mon_navire');
                var navire=nav.value;
                sel = document.getElementById('date_avaries');
                dates = sel.options[sel.selectedIndex].value;
                xhr.send("Dates=" + dates + "&Navire=" + navire);
            }
        </script>      







        <script type='text/javascript'>
 
            function getXhr(){
                                var xhr = null; 
                if(window.XMLHttpRequest) // Firefox et autres
                   xhr = new XMLHttpRequest(); 
                else if(window.ActiveXObject){ // Internet Explorer 
                   try {
                            xhr = new ActiveXObject("Msxml2.XMLHTTP");
                        } catch (e) {
                            xhr = new ActiveXObject("Microsoft.XMLHTTP");
                        }
                }
                else { // XMLHttpRequest non supporté par le navigateur 
                   alert("Votre navigateur ne supporte pas les objets XMLHTTPRequest..."); 
                   xhr = false; 
                } 
                                return xhr;
            }
 
            /**
            * Méthode qui sera appelée sur le clic du bouton
            */
            function goNavireSit(){
                var xhr = getXhr();
                // On définit ce qu'on va faire quand on aura la réponse
                xhr.onreadystatechange = function(){
                    // On ne fait quelque chose que si on a tout reçu et que le serveur est OK
                    if(xhr.readyState == 4 && xhr.status == 200){
                        ladate = xhr.responseText;
                        // On se sert de innerHTML pour rajouter les options à la liste
                        document.getElementById('date').innerHTML = ladate;

                    }
                }
 
                // Ici on va voir comment faire du post
                xhr.open("POST","date_sit.php",true);
                // ne pas oublier ça pour le post
                xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
                // ne pas oublier de poster les arguments
                // ici, l'id de l'auteur
                sel = document.getElementById('navires');
                idnavires = sel.options[sel.selectedIndex].value;
                xhr.send("idNavires="+idnavires);
            }
        </script>


        <script type='text/javascript'>
 
            function getXhr(){
                                var xhr = null; 
                if(window.XMLHttpRequest) // Firefox et autres
                   xhr = new XMLHttpRequest(); 
                else if(window.ActiveXObject){ // Internet Explorer 
                   try {
                            xhr = new ActiveXObject("Msxml2.XMLHTTP");
                        } catch (e) {
                            xhr = new ActiveXObject("Microsoft.XMLHTTP");
                        }
                }
                else { // XMLHttpRequest non supporté par le navigateur 
                   alert("Votre navigateur ne supporte pas les objets XMLHTTPRequest..."); 
                   xhr = false; 
                } 
                                return xhr;
            }
 
            /**
            * Méthode qui sera appelée sur le clic du bouton
            */
            function goDateSit(){
                var xhr = getXhr();
                // On définit ce qu'on va faire quand on aura la réponse
                xhr.onreadystatechange = function(){
                    // On ne fait quelque chose que si on a tout reçu et que le serveur est OK
                    if(xhr.readyState == 4 && xhr.status == 200){
                        lecales = xhr.responseText;
                        // On se sert de innerHTML pour rajouter les options à la liste
                        document.getElementById('sit').innerHTML = lecales;

                    }
                }
 
                // Ici on va voir comment faire du post
                xhr.open("POST","selectTableSituation.php",true);
                // ne pas oublier ça pour le post
                xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
                // ne pas oublier de poster les arguments
                // ici, l'id de l'auteur
                sel = document.getElementById('date');
                iddate = sel.options[sel.selectedIndex].value;
                xhr.send("idDate="+iddate);
            }
        </script>  


        <script type='text/javascript'>
 
            function getXhr(){
                                var xhr = null; 
                if(window.XMLHttpRequest) // Firefox et autres
                   xhr = new XMLHttpRequest(); 
                else if(window.ActiveXObject){ // Internet Explorer 
                   try {
                            xhr = new ActiveXObject("Msxml2.XMLHTTP");
                        } catch (e) {
                            xhr = new ActiveXObject("Microsoft.XMLHTTP");
                        }
                }
                else { // XMLHttpRequest non supporté par le navigateur 
                   alert("Votre navigateur ne supporte pas les objets XMLHTTPRequest..."); 
                   xhr = false; 
                } 
                                return xhr;
            }
 
            /**
            * Méthode qui sera appelée sur le clic du bouton
            */
            function camion(){
                var xhr = getXhr();
                // On définit ce qu'on va faire quand on aura la réponse
                xhr.onreadystatechange = function(){
                    // On ne fait quelque chose que si on a tout reçu et que le serveur est OK
                    if(xhr.readyState == 4 && xhr.status == 200){
                     var   lec = xhr.responseText;
                        // On se sert de innerHTML pour rajouter les options à la liste
                        document.getElementById('chauf').innerHTML = lec;
                     
                        // On se sert de innerHTML pour rajouter les options à la liste
                        

                    }
                }
 
                // Ici on va voir comment faire du post
                xhr.open("POST","selectCamions.php",true);
                // ne pas oublier ça pour le post
                xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
                // ne pas oublier de poster les arguments
                // ici, l'id de l'auteur
                sel = document.getElementById('cam');
                idcam = sel.options[sel.selectedIndex].value;
                xhr.send("idCam="+idcam);
            }
        </script>  


 <script type='text/javascript'>
 
            function getXhr(){
                                var xhr = null; 
                if(window.XMLHttpRequest) // Firefox et autres
                   xhr = new XMLHttpRequest(); 
                else if(window.ActiveXObject){ // Internet Explorer 
                   try {
                            xhr = new ActiveXObject("Msxml2.XMLHTTP");
                        } catch (e) {
                            xhr = new ActiveXObject("Microsoft.XMLHTTP");
                        }
                }
                else { // XMLHttpRequest non supporté par le navigateur 
                   alert("Votre navigateur ne supporte pas les objets XMLHTTPRequest..."); 
                   xhr = false; 
                } 
                                return xhr;
            }
 
            /**
            * Méthode qui sera appelée sur le clic du bouton
            */
            function chauffe(){
                var xhr = getXhr();
                // On définit ce qu'on va faire quand on aura la réponse
                xhr.onreadystatechange = function(){
                    // On ne fait quelque chose que si on a tout reçu et que le serveur est OK
                    if(xhr.readyState == 4 && xhr.status == 200){
                     var   lek = xhr.responseText;
                        // On se sert de innerHTML pour rajouter les options à la liste
                        document.getElementById('info_chauffeur').innerHTML = lek;
                         
                        // On se sert de innerHTML pour rajouter les options à la liste
                        

                    }
                }
 
                // Ici on va voir comment faire du post
                xhr.open("POST","selectInfoChauffeur2.php",true);
                // ne pas oublier ça pour le post
                xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
                // ne pas oublier de poster les arguments
                // ici, l'id de l'auteur
                sel = document.getElementById('chauf');
                idchauffeur = sel.options[sel.selectedIndex].value;
                xhr.send("idChauffeur="+idchauffeur);
            }
        </script>  



        <script type='text/javascript'>
 
            function getXhr(){
                                var xhr = null; 
                if(window.XMLHttpRequest) // Firefox et autres
                   xhr = new XMLHttpRequest(); 
                else if(window.ActiveXObject){ // Internet Explorer 
                   try {
                            xhr = new ActiveXObject("Msxml2.XMLHTTP");
                        } catch (e) {
                            xhr = new ActiveXObject("Microsoft.XMLHTTP");
                        }
                }
                else { // XMLHttpRequest non supporté par le navigateur 
                   alert("Votre navigateur ne supporte pas les objets XMLHTTPRequest..."); 
                   xhr = false; 
                } 
                                return xhr;
            }
 
            /**
            * Méthode qui sera appelée sur le clic du bouton
            */
            function camion2(){
                var xhr = getXhr();
                // On définit ce qu'on va faire quand on aura la réponse
                xhr.onreadystatechange = function(){
                    // On ne fait quelque chose que si on a tout reçu et que le serveur est OK
                    if(xhr.readyState == 4 && xhr.status == 200){
                     var   lec = xhr.responseText;
                        // On se sert de innerHTML pour rajouter les options à la liste
                        document.getElementById('chauf2').innerHTML = lec;
                     
                        // On se sert de innerHTML pour rajouter les options à la liste
                        

                    }
                }
 
                // Ici on va voir comment faire du post
                xhr.open("POST","selectCamions2.php",true);
                // ne pas oublier ça pour le post
                xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
                // ne pas oublier de poster les arguments
                // ici, l'id de l'auteur
                sel = document.getElementById('cam2');
                idcam = sel.options[sel.selectedIndex].value;
                xhr.send("idCam="+idcam);
            }
        </script>  


 <script type='text/javascript'>
 
            function getXhr(){
                                var xhr = null; 
                if(window.XMLHttpRequest) // Firefox et autres
                   xhr = new XMLHttpRequest(); 
                else if(window.ActiveXObject){ // Internet Explorer 
                   try {
                            xhr = new ActiveXObject("Msxml2.XMLHTTP");
                        } catch (e) {
                            xhr = new ActiveXObject("Microsoft.XMLHTTP");
                        }
                }
                else { // XMLHttpRequest non supporté par le navigateur 
                   alert("Votre navigateur ne supporte pas les objets XMLHTTPRequest..."); 
                   xhr = false; 
                } 
                                return xhr;
            }
 
            /**
            * Méthode qui sera appelée sur le clic du bouton
            */
            function chauffe2(){
                var xhr = getXhr();
                // On définit ce qu'on va faire quand on aura la réponse
                xhr.onreadystatechange = function(){
                    // On ne fait quelque chose que si on a tout reçu et que le serveur est OK
                    if(xhr.readyState == 4 && xhr.status == 200){
                     var   lek = xhr.responseText;
                        // On se sert de innerHTML pour rajouter les options à la liste
                        document.getElementById('info_chauffeur2').innerHTML = lek;
                         
                        // On se sert de innerHTML pour rajouter les options à la liste
                        

                    }
                }
 
                // Ici on va voir comment faire du post
                xhr.open("POST","selectInfoChauffeur2.php",true);
                // ne pas oublier ça pour le post
                xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
                // ne pas oublier de poster les arguments
                // ici, l'id de l'auteur
                sel = document.getElementById('chauf2');
                idchauffeur = sel.options[sel.selectedIndex].value;
                xhr.send("idChauffeur="+idchauffeur);
            }
        </script> 


  

    




 <script type="text/javascript">
  function deleteAjax2(id){
   
       if(confirm('Voulez vous vraiment supprimer ce donnée?')){
         
         $.ajax({

              type:'post',
              url:'delete.php',
              data:{delete_id:id},
              success:function(data){
              
                   $('#'+id+'colonnebl').hide('slow');

              }

         });

       }


     }

 


 </script>





 



<script type="text/javascript">
    
$(document).ready(function() {
  $('#archive-button').click(function() {
    // Insérez ici le code pour archiver les dossiers
  });
});


</script>





<script type="text/javascript">
function filterOptions() {
  var input = document.getElementById("myInput");
  var select = document.getElementById("came");
  var filter = input.value.toLowerCase();

  // Parcourir toutes les options du select à partir de l'index 1 (excluant l'option "Sélectionnez un camion")
  for (var i = 1; i < select.options.length; i++) {
    var option = select.options[i];
    var text = option.textContent.toLowerCase();

    // Vérifier si le texte de l'option contient le filtre saisi
    if (text.indexOf(filter) > -1) {
      option.style.display = ""; // Afficher l'option
    } else {
      option.style.display = "none"; // Masquer l'option
    }
  }

  // Sélectionner automatiquement la première option correspondante
  select.selectedIndex = 0; // Réinitialiser la sélection

  for (var i = 1; i < select.options.length; i++) {
    var option = select.options[i];
    if (option.style.display !== "none") {
      select.selectedIndex = i; // Sélectionner l'option correspondante
      break;
    }
  }
}


</script>


<script type="text/javascript">
function filtreChauffeurs() {
  var input = document.getElementById("myInput2");
  var select = document.getElementById("chauf");
  var filter = input.value.toLowerCase();


  

  // Parcourir toutes les options du select à partir de l'index 1 (excluant l'option "Sélectionnez un camion")
  for (var i = 1; i < select.options.length; i++) {
    
    var option = select.options[i];


    var text = option.textContent.toLowerCase();

    // Vérifier si le texte de l'option contient le filtre saisi
    if (text.indexOf(filter) > -1) {
      option.style.display = ""; // Afficher l'option
     
    } else {
      option.style.display = "none"; // Masquer l'option
    }
  }


  // Sélectionner automatiquement la première option correspondante
  select.selectedIndex = 0; // Réinitialiser la sélection

  for (var i = 1; i < select.options.length; i++) {
    var option = select.options[i];
    if (option.style.display !== "none") {
      select.selectedIndex = i; // Sélectionner l'option correspondante
      break;
    }
  }

}



</script>


<script>
  // Récupérer le bouton de fermeture d'erreur
  var closeButton = document.getElementById('close_erreur');

  // Récupérer le div d'erreur
  var errorDiv = document.getElementById('erreur');

  // Ajouter un gestionnaire d'événement au clic sur le bouton de fermeture
  closeButton.addEventListener('click', function() {
    // Masquer le div d'erreur en modifiant sa propriété de style
    errorDiv.style.display = 'none';
  });
</script>






<script type="text/javascript">


    $(document).ready(function(){
    $(document).on('click','a[data-role=update_register]',function(){
        var id = $(this).data('id');
        var date = $('#'+id+'date_rm').text();
        var heure = $('#'+id+'heure_rm').text();
        var bl = $('#'+id+'bl_rm').text();
        var sac = $('#'+id+'sac_rm').text();
        var camion = $('#'+id+'camion_rm').text();
        var transport = $('#'+id+'transporteur_rm').text();
        var chauffeur = $('#'+id+'chauffeur_rm').text();
        var id_camion = $('#'+id+'id_camion_rm').text();
        var id_chauffeur = $('#'+id+'id_chauffeur_rm').text();
        var id_declaration = $('#'+id+'id_declaration_rm').text();
        var declaration = $('#'+id+'declaration_rm').text();
        var cale = $('#'+id+'cale_rm').text();
        var dis_bl = $('#'+id+'dis_bl_rm').text();
        var poids_sac = $('#'+id+'poids_sac_rm').text()

           var existingOption = $('#declaration_m_rm option[value="' + id_declaration + '"]');
if (existingOption.length > 0) {
   // Mettre à jour le texte de l'option existante
   existingOption.text(declaration);
} else {
   // Ajouter une nouvelle option avec la valeur et le texte correspondants
   var newOption = $('<option>', {
      value: id_declaration,
      text: declaration
   });
   $('#declaration_m_rm').prepend(newOption);
   // Sélectionner l'option par défaut
   newOption.prop('selected', true);
}

var existingOptioncale = $('#declaration_m_rm option[value="' + cale + '"]');
if (existingOptioncale.length > 0) {
   // Mettre à jour le texte de l'option existante
   existingOptioncale.text(cale);
} else {
   // Ajouter une nouvelle option avec la valeur et le texte correspondants
   var newOption = $('<option>', {
      value: cale,
      text: cale
   });
   $('#cale_m_rm').prepend(newOption);
   // Sélectionner l'option par défaut
   newOption.prop('selected', true);
}

        $('#cale_m_rm').val(cale);
        $('#declaration_m_rm').val(id_declaration);
        $('#date_m_rm').val(date);
        $('#heure_m_rm').val(heure);
        $('#bl_m_rm').val(bl);
        $('#sac_m_rm').val(sac);
        $('#myInput_m_rm').val(camion);
        $('#myInputTransp_m_rm').val(transport);
        $('#myInputc_m_rm').val(chauffeur);
        $('#val_input2_m_rm').val(id_camion);
        $('#val_input2c_m_rm').val(id_chauffeur);
        $('#dis_bl_m_rm').val(dis_bl);
        $('#poids_sac_m_rm').val(poids_sac);

        $('#id_m_rm').val(id);


        
        $('#modif_register').modal('toggle');
    });
    
    $('#mod').click(function(){
        var date = $('#date_m_rm').val();
        date=date.replace(' ','');
        var heure = $('#heure_m_rm').val();
        var declaration = $('#declaration_m_rm').val();
        var cale = $('#cale_m_rm').val();
        var camion = $('#val_input2_m_rm').val();
        var chauffeur = $('#val_input2c_m_rm').val();
        var bl = $('#bl_m_rm').val();
        var sac = $('#sac_m_rm').val();
        var dis_bl = $('#dis_bl_m_rm').val();
        var poids_sac = $('#poids_sac_m_rm').val();
     
            var id = $('#id_m_rm').val();
        $('#frontend').css('display', 'none');

        
        $.ajax({
        url:'modification.php',
        method:'post',
        data:{date:date,heure:heure,declaration:declaration,cale:cale,camion:camion,chauffeur:chauffeur,bl:bl,id:id,dis_bl:dis_bl,sac:sac,poids_sac:poids_sac},
        success: function(response){
            $('#TableSain').html(response);

        $('#modif_register').modal('toggle');
        }
    });
    });
});

</script>






<script type="text/javascript">


    $(document).ready(function(){
    $(document).on('click','a[data-role=btn_register]',function(){
        
   // Mettre à jour le texte de l'option existante
  

        
        
  
        var dates = $('#datesain').val();
        //date=date.replace(' ','');
        var heure = $('#heuresain').val();
        var navire = $('#naviresain').val();
        var type = $('#typesain').val();
        var bl = $('#blsain').val();
        var poids_sac = $('#poids_sacssain').val();
        var declaration = $('#declarationsain').val();
        var cale = $('#calesain').val();
        var id_dis = $('#id_dissain').val();
        var client = $('#clientsain').val();
        var mangasin = $('#mangasinsain').val();
        var destinataire = $('#destinatairesain').val();
        var val_input2 = $('#val_input2').val();
        var val_input2c = $('#val_input2c').val();
        var sac = $('#sacsain').val();
        var poids = $('#poidssain').val();
        var id_produit = $('#produitsain').val();
        $('#enregistrement').modal('toggle');
  
        
        $.ajax({
        url:'ajouttablesain.php',
        method:'post',
        data:{dates:dates,heure:heure,navire:navire,type:type,poids_sac:poids_sac,declaration:declaration,client:client,mangasin:mangasin,destinataire:destinataire,val_input2:val_input2,val_input2c:val_input2c,sac:sac,poids:poids,cale:cale,id_dis:id_dis,bl:bl,id_produit:id_produit},
        success: function(response){
            $('#TableSain').html(response);

        
        }
    });
    });
});

</script>







<script type="text/javascript">


    $(document).ready(function(){
    $(document).on('click','a[data-role=btn_transfert_avaries]',function(){
        
   // Mettre à jour le texte de l'option existante
  

        
        
  
        var dates = $('#datetrav').val();
        //date=date.replace(' ','');
        var heure = $('#heuretrav').val();
        var navire = $('#naviretrav').val();
       // var type = $('#typesain').val();
        var bl = $('#bltrav').val();
        var poids_sac = $('#poids_sactrav').val();
        var declaration = $('#declarationtrav').val();
        var cale = $('#caletrav').val();
        var id_dis = $('#id_distrav').val();
        var client = $('#clienttrav').val();
        var mangasin = $('#mangasintrav').val();
        var destinataire = $('#destinatairetrav').val();
        var autre_destinataire = $('#autre_destinatairetrav').val();
        var val_input3 = $('#val_input3').val();
        var val_input3c = $('#val_input3c').val();
        var sacf = $('#sacftrav').val();
        var sacm = $('#sacmtrav').val();
        var poidsf = $('#poidsftrav').val();
        var poidsm = $('#poidsmtrav').val();
        var id_produit = $('#produittrav').val();
        $('#enregistrement_transfert').modal('toggle');
  
        
        $.ajax({
        url:'ajouttransfertavaries.php',
        method:'post',
        data:{dates:dates,heure:heure,navire:navire,poids_sac:poids_sac,declaration:declaration,client:client,mangasin:mangasin,destinataire:destinataire,val_input3:val_input3,val_input3c:val_input3c,sacf:sacf,poidsf:poidsf,sacm:sacm,poidsm:poidsm,cale:cale,id_dis:id_dis,bl:bl,id_produit:id_produit,autre_destinataire:autre_destinataire},
        success: function(response){
            $('#TableAvariesTrans').html(response);

        
        }
    });
    });
});

</script>




<script type="text/javascript">


    $(document).ready(function(){
    $(document).on('click','a[data-role=btn_avaries_debarquement]',function(){
        
   // Mettre à jour le texte de l'option existante
  

        
        
  
        var dates = $('#dateavdeb').val();
        //date=date.replace(' ','');
       // var heure = $('#heuretrav').val();
        var navire = $('#navireavdeb').val();
       // var type = $('#typesain').val();
       // var bl = $('#bltrav').val();
        var poids_sac = $('#poids_sacavdeb').val();
       // var declaration = $('#declarationtrav').val();
        var cale = $('#caleavdeb').val();
        var id_dis = $('#id_disavdeb').val();
       // var client = $('#clienttrav').val();
     //   var mangasin = $('#mangasintrav').val();
       // var destinataire = $('#destinatairetrav').val();
      //  var autre_destinataire = $('#autre_destinatairetrav').val();
      //  var val_input3 = $('#val_input3').val();
      //  var val_input3c = $('#val_input3c').val();
        var sacf = $('#sacfavdeb').val();
        var sacm = $('#sacmavdeb').val();
       // var poidsf = $('#poidsftrav').val();
      //  var poidsm = $('#poidsmtrav').val();
        var id_produit = $('#produitavdeb').val();
        $('#Les_avaries2').modal('toggle');
  
        
        $.ajax({
        url:'ajoutavariesdebarquement.php',
        method:'post',
        data:{dates:dates,navire:navire,poids_sac:poids_sac,sacf:sacf,sacm:sacm,cale:cale,id_dis:id_dis,id_produit:id_produit},
        success: function(response){
            $('#avaries_debarquement').html(response);

        
        }
    });
    });
});

</script>







<script type="text/javascript">


    $(document).ready(function(){
    $(document).on('click','a[data-role=btn_situation_sacherie]',function(){
        
   // Mettre à jour le texte de l'option existante
 
        var formData = $('#myForm').serializeArray();
        $('#Les_avaries').modal('toggle');
        
        $.ajax({
            url: 'ajoutsituation24H.php',
            method: 'post',
            data: formData,
            success: function(response) {
              //  $('#main').html(response);        
        }
    });
    });
});

</script>



















<script type="text/javascript">


    $(document).ready(function(){
    $(document).on('click','a[data-role=update_avaries_deb]',function(){
        var id = $(this).data('id');
        var date = $('#'+id+'date_avaries_deb').text();
        var id_navire = $('#'+id+'id_navire_avaries_deb').text();
        
        var sacf = $('#'+id+'flasque_avaries_deb').text();
        var sacm = $('#'+id+'mouille_avaries_deb').text();
        var id_dis = $('#'+id+'id_dis_avaries_deb').text();
        $('#date_avdeb').val(date);
        $('#sacf_avdeb').val(sacf);
        $('#sacm_avdeb').val(sacm);
         $('#id_avdeb').val(id);
          $('#id_navire_avdeb').val(id_navire);
          $('#id_dis_avdeb').val(id_dis);
    

        
        $('#modif_avaries_deb').modal('toggle');
    });
    
    $('#mod_avaries_deb').click(function(){
      var date=  $('#date_avdeb').val();
          date.replace(' ','');
      var sacf=  $('#sacf_avdeb').val();
      var sacm= $('#sacm_avdeb').val();
      var id= $('#id_avdeb').val();
      var id_dis= $('#id_dis_avdeb').val();
      var id_navire=  $('#id_navire_avdeb').val();
       // $('#frontend').css('display', 'none');

        
        $.ajax({
        url:'modifier_avaries_deb.php',
        method:'post',
        data:{date:date,id:id,sacf:sacf,sacm:sacm,id_navire:id_navire,id_dis:id_dis},
        success: function(response){
            $('#avaries_debarquement').html(response);

        $('#modif_avaries_deb').modal('toggle');
        }
    });
    });
});

</script>


<script type="text/javascript">


    $(document).ready(function(){
    $(document).on('click','a[data-role=update_avaries_deb2]',function(){
        var id = $(this).data('id');
        var date = $('#'+id+'date_avaries_deb').text();
        var id_navire = $('#'+id+'id_navire_avaries_deb').text();
        
        var sacf = $('#'+id+'flasque_avaries_deb').text();
        var sacm = $('#'+id+'mouille_avaries_deb').text();
        $('#date_avdeb2').val(date);
        $('#sacf_avdeb2').val(sacf);
        $('#sacm_avdeb2').val(sacm);
         $('#id_avdeb2').val(id);
          $('#id_navire_avdeb2').val(id_navire);
    

        
        $('#modif_avaries_deb2').modal('toggle');
    });
    
    $('#mod_avaries_deb2').click(function(){
      var date=  $('#date_avdeb2').val();
          date.replace(' ','');
      var sacf=  $('#sacf_avdeb2').val();
      var sacm= $('#sacm_avdeb2').val();
      var id= $('#id_avdeb2').val();
      var id_navire=  $('#id_navire_avdeb2').val();
       // $('#frontend').css('display', 'none');

        
        $.ajax({
        url:'modifier_avaries_deb2.php',
        method:'post',
        data:{date:date,id:id,sacf:sacf,sacm:sacm,id_navire:id_navire},
        success: function(response){
            $('#avaries_debarquement').html(response);

        $('#modif_avaries_deb2').modal('toggle');
        }
    });
    });
});

</script>









<script type="text/javascript">
    
function scrollToTopOfDiv() {
  var element = $('#TableSain');
  
 
var offset = element.offset();
  $(
 
'html, body').animate({ scrollTop: offset.top }, 'slow');
}

</script>





<script type="text/javascript">


    $(document).ready(function(){
    $(document).on('click','a[data-role=update_register_avaries]',function(){
        var id = $(this).data('id');
        var date = $('#'+id+'date_av').text();
        var heure = $('#'+id+'heure_av').text();
        var bl = $('#'+id+'bl_av').text();
        var sacf = $('#'+id+'sacf_av').text();
        var sacm = $('#'+id+'sacm_av').text();
        var poidsf = $('#'+id+'poidsf_av').text();
        var poidsm = $('#'+id+'poidsm_av').text();
        var camion = $('#'+id+'camion_av').text();
        var transport = $('#'+id+'transporteur_av').text();
        var chauffeur = $('#'+id+'chauffeur_av').text();
        var id_camion = $('#'+id+'id_camion_av').text();
        var id_chauffeur = $('#'+id+'id_chauffeur_av').text();
        var id_declaration = $('#'+id+'id_declaration_av').text();
        var declaration = $('#'+id+'declaration_av').text();
        var cale = $('#'+id+'cale_av').text();
        var dis_bl = $('#'+id+'dis_bl_av').text();
        var poids_sac = $('#'+id+'poids_sac_av').text();


           var existingOption = $('#declaration_m_av option[value="' + id_declaration + '"]');
if (existingOption.length > 0) {
   // Mettre à jour le texte de l'option existante
   existingOption.text(declaration);
} else {
   // Ajouter une nouvelle option avec la valeur et le texte correspondants
   var newOption = $('<option>', {
      value: id_declaration,
      text: declaration
   });
   $('#declaration_m_av').prepend(newOption);
   // Sélectionner l'option par défaut
   newOption.prop('selected', true);
}

var existingOptioncale = $('#cale_m_av option[value="' + cale + '"]');
if (existingOptioncale.length > 0) {
   // Mettre à jour le texte de l'option existante
   existingOptioncale.text(cale);
} else {
   // Ajouter une nouvelle option avec la valeur et le texte correspondants
   var newOption = $('<option>', {
      value: cale,
      text: cale
   });
   $('#cale_m_av').prepend(newOption);
   // Sélectionner l'option par défaut
   newOption.prop('selected', true);
} 

         $('#cale_m_av').val(cale);
         $('#declaration_m_av').val(id_declaration);
         $('#date_m_av').val(date);
        
        $('#bl_m_av').val(bl);
        $('#sacf_m_av').val(sacf);
        $('#poidsf_m_av').val(poidsf);
         $('#sacm_m_av').val(sacm);
        $('#poidsm_m_av').val(poidsm);
        $('#myInput_m_av').val(camion);
        $('#myInputTransp_m_av').val(transport);
        $('#myInputc_m_av').val(chauffeur);
        $('#val_input2_m_av').val(id_camion);
        $('#val_input2c_m_av').val(id_chauffeur);
        $('#dis_bl_m_av').val(dis_bl);
        $('#poids_sac_m_av').val(poids_sac);

        $('#id_m_av').val(id);
                        

        $('#heure_m_av').val(heure);
        
        $('#modif_register_avaries').modal('toggle');
    });
    
    $('#mod_avaries').click(function(){
        var date = $('#date_m_av').val();
       date=date.replace(' ','');
        var heure = $('#heure_m_av').val();
     var declaration = $('#declaration_m_av').val();
        var cale = $('#cale_m_av').val();
        var camion = $('#val_input2_m_av').val();
        var chauffeur = $('#val_input2c_m_av').val();
        var bl = $('#bl_m_av').val();
        var sacf = $('#sacf_m_av').val();
        var sacm = $('#sacm_m_av').val();
        var poidsf = $('#poidsf_m_av').val();
        var poidsm = $('#poidsm_m_av').val();
        var dis_bl = $('#dis_bl_m_av').val();
        var poids_sac = $('#poids_sac_m_av').val();
     
            var id = $('#id_m_av').val();
        

        
        $.ajax({
        url:'modification_avaries.php',
        method:'post',
        data:{date:date,heure:heure,declaration:declaration,cale:cale,camion:camion,chauffeur:chauffeur,bl:bl,id:id,dis_bl:dis_bl,sacf:sacf,sacm:sacm,poidsf:poidsf,poidsm:poidsm,poids_sac:poids_sac},
        success: function(response){
            $('#tr_avariess').html(response);

        $('#modif_register_avaries').modal('toggle');
        
        }
    });
    });
});

</script>




<script type="text/javascript">


    $(document).ready(function(){
    $(document).on('click','a[data-role=update_register_vrac]',function(){
        var id = $(this).data('id');
        var date = $('#'+id+'date_rm').text();
        var heure = $('#'+id+'heure_rm').text();
        var bl = $('#'+id+'bl_rm').text();
        var sac = $('#'+id+'sac_rm').text();
        var poids = $('#'+id+'poids_rm').text();
        var camion = $('#'+id+'camion_rm').text();
        var transport = $('#'+id+'transporteur_rm').text();
        var chauffeur = $('#'+id+'chauffeur_rm').text();
        var id_camion = $('#'+id+'id_camion_rm').text();
        var id_chauffeur = $('#'+id+'id_chauffeur_rm').text();
        var id_declaration = $('#'+id+'id_declaration_rm').text();
        var declaration = $('#'+id+'declaration_rm').text();
        var cale = $('#'+id+'cale_rm').text();
        var dis_bl = $('#'+id+'dis_bl_rm').text();
        var poids_sac = $('#'+id+'poids_sac_rm').text();


           var existingOption = $('#declaration_m_rm option[value="' + id_declaration + '"]');
if (existingOption.length > 0) {
   // Mettre à jour le texte de l'option existante
   existingOption.text(declaration);
} else {
   // Ajouter une nouvelle option avec la valeur et le texte correspondants
   var newOption = $('<option>', {
      value: id_declaration,
      text: declaration
   });
   $('#declaration_m_vrac').prepend(newOption);
   // Sélectionner l'option par défaut
   newOption.prop('selected', true);
}

var existingOptioncale = $('#declaration_m_vrac option[value="' + cale + '"]');
if (existingOptioncale.length > 0) {
   // Mettre à jour le texte de l'option existante
   existingOptioncale.text(cale);
} else {
   // Ajouter une nouvelle option avec la valeur et le texte correspondants
   var newOption = $('<option>', {
      value: cale,
      text: cale
   });
   $('#cale_m_vrac').prepend(newOption);
   // Sélectionner l'option par défaut
   newOption.prop('selected', true);
}

         $('#cale_m_vrac').val(cale);
         $('#declaration_m_vrac').val(id_declaration);
         $('#date_m_vrac').val(date);
        $('#heure_m_vrac').val(heure);
        $('#bl_m_vrac').val(bl);
        $('#sac_m_vrac').val(sac);
        $('#poids_m_vrac').val(poids);
        $('#myInput_m_vrac').val(camion);
        $('#myInputTransp_m_vrac').val(transport);
        $('#myInputc_m_vrac').val(chauffeur);
        $('#val_input2_m_vrac').val(id_camion);
        $('#val_input2c_m_vrac').val(id_chauffeur);
        $('#dis_bl_m_vrac').val(dis_bl);
        $('#poids_sac_m_vrac').val(poids_sac);

        $('#id_m_vrac').val(id);



        
        $('#modif_register_vrac').modal('toggle');
    });
    
    $('#mod_vrac').click(function(){
        var date = $('#date_m_vrac').val();
        date=date.replace(' ','');
        var heure = $('#heure_m_vrac').val();
        var declaration = $('#declaration_m_vrac').val();
        var cale = $('#cale_m_vrac').val();
        var camion = $('#val_input2_m_vrac').val();
        var chauffeur = $('#val_input2c_m_vrac').val();
        var bl = $('#bl_m_vrac').val();
        var sac = $('#sac_m_vrac').val();
        var poids = $('#poids_m_vrac').val();
        var dis_bl = $('#dis_bl_m_vrac').val();
        var poids_sac = $('#poids_sac_m_vrac').val();
     
            var id = $('#id_m_vrac').val();
            $('#frontend').css('display', 'none');
        

        
        $.ajax({
        url:'modification_vrac.php',
        method:'post',
        data:{date:date,heure:heure,declaration:declaration,cale:cale,camion:camion,chauffeur:chauffeur,bl:bl,id:id,dis_bl:dis_bl,sac:sac,poids_sac:poids_sac,poids:poids},
        success: function(response){
            $('#TableSain').html(response);

        $('#modif_register_vrac').modal('toggle');
        }
    });
    });
});

</script>





<script type="text/javascript">


    $(document).ready(function(){
    $(document).on('click','a[data-role=update_register_vrac0]',function(){
        var id = $(this).data('id');
        var date = $('#'+id+'date_rm').text();
        var heure = $('#'+id+'heure_rm').text();
        var bl = $('#'+id+'bl_rm').text();
    
        var poids = $('#'+id+'poids_rm').text();
        var camion = $('#'+id+'camion_rm').text();
        var transport = $('#'+id+'transporteur_rm').text();
        var chauffeur = $('#'+id+'chauffeur_rm').text();
        var id_camion = $('#'+id+'id_camion_rm').text();
        var id_chauffeur = $('#'+id+'id_chauffeur_rm').text();
        var id_declaration = $('#'+id+'id_declaration_rm').text();
        var declaration = $('#'+id+'declaration_rm').text();
        var cale = $('#'+id+'cale_rm').text();
        var dis_bl = $('#'+id+'dis_bl_rm').text();
        var poids_sac = $('#'+id+'poids_sac_rm').text();


           var existingOption = $('#declaration_m_rm option[value="' + id_declaration + '"]');
if (existingOption.length > 0) {
   // Mettre à jour le texte de l'option existante
   existingOption.text(declaration);
} else {
   // Ajouter une nouvelle option avec la valeur et le texte correspondants
   var newOption = $('<option>', {
      value: id_declaration,
      text: declaration
   });
   $('#declaration_m_vrac0').prepend(newOption);
   // Sélectionner l'option par défaut
   newOption.prop('selected', true);
}

var existingOptioncale = $('#declaration_m_vrac option[value="' + cale + '"]');
if (existingOptioncale.length > 0) {
   // Mettre à jour le texte de l'option existante
   existingOptioncale.text(cale);
} else {
   // Ajouter une nouvelle option avec la valeur et le texte correspondants
   var newOption = $('<option>', {
      value: cale,
      text: cale
   });
   $('#cale_m_vrac0').prepend(newOption);
   // Sélectionner l'option par défaut
   newOption.prop('selected', true);
}

         $('#cale_m_vrac0').val(cale);
         $('#declaration_m_vrac0').val(id_declaration);
         $('#date_m_vrac0').val(date);
        $('#heure_m_vrac0').val(heure);
        $('#bl_m_vrac0').val(bl);
        
        $('#poids_m_vrac0').val(poids);
        $('#myInput_m_vrac0').val(camion);
        $('#myInputTransp_m_vrac0').val(transport);
        $('#myInputc_m_vrac0').val(chauffeur);
        $('#val_input2_m_vrac0').val(id_camion);
        $('#val_input2c_m_vrac0').val(id_chauffeur);
        $('#dis_bl_m_vrac0').val(dis_bl);
        $('#poids_sac_m_vrac0').val(poids_sac);

        $('#id_m_vrac0').val(id);


        
        $('#modif_register_vrac0').modal('toggle');
    });
    
    $('#mod_vrac0').click(function(){
        var date = $('#date_m_vrac0').val();
        //date=date.replace(' ','');
        var heure = $('#heure_m_vrac0').val();
        var declaration = $('#declaration_m_vrac0').val();
        var cale = $('#cale_m_vrac0').val();
        var camion = $('#val_input2_m_vrac0').val();
        var chauffeur = $('#val_input2c_m_vrac0').val();
        var bl = $('#bl_m_vrac0').val();
        
        var poids = $('#poids_m_vrac0').val();
        var dis_bl = $('#dis_bl_m_vrac0').val();
        var poids_sac = $('#poids_sac_m_vrac0').val();
     
            var id = $('#id_m_vrac0').val();
            $('#frontend').css('display', 'none');
        

        
        $.ajax({
        url:'modification_vrac0.php',
        method:'post',
        data:{date:date,heure:heure,declaration:declaration,cale:cale,camion:camion,chauffeur:chauffeur,bl:bl,id:id,dis_bl:dis_bl,poids_sac:poids_sac,poids:poids},
        success: function(response){
            $('#TableSain').html(response);

        $('#modif_register_vrac0').modal('toggle');
        }
    });
    });
});

</script>




<script type="text/javascript">


    $(document).ready(function(){
    $(document).on('click','a[data-role=fermer]',function(){
        $('#LesErreurs').css('display', 'none');
    });
    
    
});

</script>





<script type="text/javascript">
  function deleteAjax2m(id){
   
       if(confirm('Voulez vous vraiment supprimer ce donnée?')){
        var dis_bl = $('#'+id+'dis_bl_rm').text();
         //var navire=navires.text();
         //$("#masquage").hide();
         $('#frontend').css('display', 'none');

         
         $.ajax({

              type:'post',
              url:'delete2m.php',
              data:{delete_id:id,dis_bl:dis_bl},
              success:function(response){
              
                   $('#main').html(response);
                   scrollToTopOfDiv();

              }

         });

       }


     }

 


 </script>



 <script type="text/javascript">
  function delete_avaries_deb(id){
   
       if(confirm('Voulez vous vraiment supprimer ce donnée?')){
        var id_navire = $('#'+id+'id_navire_avaries_deb').text();
         var id_dis = $('#'+id+'id_dis_avaries_deb').text();
         //var navire=navires.text();
         //$("#masquage").hide();
         //$('#frontend').css('display', 'none');
         
         $.ajax({

              type:'post',
              url:'delete_avaries_deb.php',
              data:{delete_id:id,id_navire:id_navire,id_dis:id_dis},
              success:function(response){
              
                   $('#avaries_debarquement').html(response);

              }

         });

       }


     }

 


 </script>


 <script type="text/javascript">
  function delete_avaries_deb2(id){
   
       if(confirm('Voulez vous vraiment supprimer ce donnée?')){
        var id_navire = $('#'+id+'id_navire_avaries_deb').text();
        var date = $('#'+id+'date_avaries_deb').text();
         //var navire=navires.text();
         //$("#masquage").hide();
         //$('#frontend').css('display', 'none');
         
         $.ajax({

              type:'post',
              url:'delete_avaries_deb2.php',
              data:{delete_id:id,id_navire:id_navire,date:date},
              success:function(response){
              
                   $('#avaries_debarquement').html(response);

              }

         });

       }


     }

 


 </script>





 <script type="text/javascript">
  function deleteAvaries(id){
   
       if(confirm('Voulez vous vraiment supprimer ce donnée?')){
        var dis_bl = $('#'+id+'disbl').text();
         //var navire=navires.text();
        // $("#tr_avaries").hide();
         
         $.ajax({

              type:'post',
              url:'delete_avaries.php',
              data:{delete_id:id,dis_bl:dis_bl},
              success:function(response){
              
                   $('#tr_avariess').html(response);

              }

         });

       }


     }

 


 </script>


<script type="text/javascript">
  function deleteAjax(id){
   
       if(confirm('Voulez vous vraiment supprimer ce donnée?')){
        var dis_bl = $('#'+id+'dis_bl_rm').text();
         //var navire=navires.text();
         
         $.ajax({

              type:'post',
              url:'delete.php',
              data:{delete_id:id,dis_bl:dis_bl},
              success:function(response){
              
                   $('#TableSain').html(response);

              }

         });

       }


     }

 


 </script>


<script>
  function visibleSain() {
    var sain = document.getElementById("TableSain");
    var deb = document.getElementById("TableAvariesTrans");
    var rep = document.getElementById("avaries_debarquement");

    if (sain.style.display === "none") {
      sain.style.display = "table";
      deb.style.display = "none";
      rep.style.display = "none";
     
     

       sain.scrollIntoView({ behavior: 'smooth' });
     
    } else {
      sain.style.display = "none";
     
    }
    
    
  }
</script>


<script>
  function visibleAvariesDeb() {
    var sain = document.getElementById("TableSain");
    var deb = document.getElementById("TableAvariesTrans");
    var rep = document.getElementById("avaries_debarquement");

    if (rep.style.display === "none") {
      rep.style.display = "table";
      sain.style.display = "none";
      deb.style.display = "none";
     
     

       rep.scrollIntoView({ behavior: 'smooth' });
     
    } else {
      rep.style.display = "none";
     
    }
    
    
  }
</script>

<script>
  function visibleAvariesTrans() {
    var sain = document.getElementById("TableSain");
    var deb = document.getElementById("TableAvariesTrans");
    var rep = document.getElementById("avaries_debarquement");

    if (deb.style.display === "none") {
      deb.style.display = "table";
      rep.style.display = "none";
      sain.style.display = "none";
     
     

       deb.scrollIntoView({ behavior: 'smooth' });
     
    } else {
      deb.style.display = "none";
     
    }
    
    
  }
</script>






<script>
  function visibleSain2() {
    var sain = document.getElementById("TableSain");
    var deb = document.getElementById("TableAvariesTrans2");
    var rep = document.getElementById("avaries_debarquement2");

    if (sain.style.display === "none") {
      sain.style.display = "table";
      deb.style.display = "none";
      rep.style.display = "none";
     
     

       sain.scrollIntoView({ behavior: 'smooth' });
     
    } else {
      sain.style.display = "none";
     
    }
    
    
  }
</script>


<script>
  function visibleAvariesDeb2() {
    var sain = document.getElementById("TableSain");
    var deb = document.getElementById("TableAvariesTrans2");
    var rep = document.getElementById("avaries_debarquement2");

    if (rep.style.display === "none") {
      rep.style.display = "table";
      sain.style.display = "none";
      deb.style.display = "none";
     
     

       rep.scrollIntoView({ behavior: 'smooth' });
     
    } else {
      rep.style.display = "none";
     
    }
    
    
  }
</script>

<script>
  function visibleAvariesTrans2() {
    var sain = document.getElementById("TableSain");
    var deb = document.getElementById("TableAvariesTrans2");
    var rep = document.getElementById("avaries_debarquement2");

    if (deb.style.display === "none") {
      deb.style.display = "table";
     
      sain.style.display = "none";
     
     

       deb.scrollIntoView({ behavior: 'smooth' });
     
    } else {
      deb.style.display = "none";
     
    }
    
    
  }
</script>








 </body>
</html>
